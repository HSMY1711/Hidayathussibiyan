/**
 * Arabimalayalam Transliterator — A product of M&M
 * Powered by M&M T17 AI · T17 Engine
 * 
 * "Helps Students to Transliterate Texts in Malayalam to Arabimalayalam"
 * 
 * Version: M&M T17 AI 2.1
 * Pure standalone JavaScript library — Zero external dependencies.
 * 100% Offline & Local Execution — NO Gemini/OpenAI or external network APIs.
 *
 * Core Architectural Paradigm:
 * - Multi-Candidate Grapheme/Phoneme Mapping:
 *   Every ambiguous Malayalam sound maintains a probability-weighted candidate set:
 *     ഫ → [ف, پَھ, ...]
 *     സ → [س, ص, ث, ...]
 *     ത → [ت, ط, ...]
 *     ക → [ک, ق, ...]
 *     ഖ → [کَھ, خ, ق, ...]
 *     ഹ → [ھ, ح, ه, ...]
 *     ദ → [د, ذ, ض, ...]
 *     ധ → [دَھ, ذ, ...]
 *     ശ → [ش, ص, ...]
 *     ഷ → [ۺ, ش, ...]
 *     അ → [اَ, عَ, أَ, ...]
 *     ാ → [َا, َى, ...]
 * - Contextual & Morphological Linguistic Analysis:
 *   Evaluates Malayalam pronunciation, syllable structure (onset, nucleus, coda),
 *   word position, n-gram phonological context, Sanskrit vs Dravidian roots,
 *   Arabic/Persian loanword wazan/patterns (Mustaf'al, Fa'il, Maf'ul, etc.), and name recognition.
 * - Dynamic Candidate Scoring & Probabilistic Ranking:
 *   Score(C) = BaseWeight + ContextBonus + MorphPatternBonus + LexicalBonus + Coherence
 *   Selects highest-probability candidate while preserving alternative hypotheses.
 * - Centralized, Declarative Knowledge System:
 *   Extensible API (registerCandidate, registerPattern, registerLexicalEntry)
 *   enabling endless linguistic rules without rewriting core transliterator logic.
 * - Full Debug & Research Inspection Trace:
 *   Provides detailed step-by-step trace of normalization, syllables, candidate generation,
 *   rule triggers, and score rankings.
 */

(function (root, factory) {
  if (typeof define === 'function' && define.amd) {
    define([], factory);
  } else if (typeof module === 'object' && module.exports) {
    module.exports = factory();
  } else {
    root.ArabiMalayalam = factory();
  }
}(typeof self !== 'undefined' ? self : this, function () {

  // Engine Metadata
  const ENGINE_INFO = {
    name: 'M&M T17 AI · T17 Engine',
    version: '18.0-NEURO-LINGUISTIC',
    product: 'Arabimalayalam Transliterator a product of M&M',
    tagline: 'Helps Students to Transliterate Texts in Malayalam to Arabimalayalam'
  };

  // =========================================================================
  // 1. EXTENSIBLE LINGUISTIC KNOWLEDGE BASE
  // =========================================================================

  /**
   * Centralized Knowledge Base:
   * Holds candidate hypotheses, base weights, linguistic tags, and evaluation conditions.
   */
  const LINGUISTIC_KNOWLEDGE_BASE = {
    // Ambiguous Phonemes / Graphemes mapping to candidate options
    candidates: {
      'ഫ': [
        {
          arabi: 'ف',
          baseWeight: 0.50,
          tags: ['loanword_fricative', 'arabic_fa', 'persian', 'english'],
          description: 'അറബി/പേർഷ്യൻ/ഇംഗ്ലീഷ് വായ്പാ പദങ്ങളിലെ Fa (ف)',
          condition: (ctx) => ctx.isArabicOrigin || ctx.isEnglishLoan || ctx.hasFaPattern
        },
        {
          arabi: 'پَھ',
          baseWeight: 0.50,
          tags: ['dravidian_aspirate', 'sanskrit_pha'],
          description: 'മലയാള തനിമഹാപ്രാണ / സംസ്കൃത Pha (پَھ)',
          condition: (ctx) => !ctx.isArabicOrigin && !ctx.isEnglishLoan
        }
      ],
      'സ': [
        {
          arabi: 'س',
          baseWeight: 0.70,
          tags: ['dravidian_default', 'sin'],
          description: 'സാധാരണ ദ്രാവിഡ ശബ്ദം Sin (س)',
          condition: (ctx) => true
        },
        {
          arabi: 'ص',
          baseWeight: 0.20,
          tags: ['arabic_emphatic', 'sad'],
          description: 'അറബി ഗംഭീര ശബ്ദം Sad (ص)',
          condition: (ctx) => ctx.isEmphaticContext || ctx.hasSadPattern
        },
        {
          arabi: 'ث',
          baseWeight: 0.10,
          tags: ['arabic_interdental', 'tha'],
          description: 'അറബി ദന്തമൂലീയ ശബ്ദം Tha (ث)',
          condition: (ctx) => ctx.hasThaPattern
        }
      ],
      'ത': [
        {
          arabi: 'ت',
          baseWeight: 0.75,
          tags: ['dravidian_default', 'ta'],
          description: 'സാധാരണ ദ്രാവിഡ Ta (ت)',
          condition: (ctx) => true
        },
        {
          arabi: 'ط',
          baseWeight: 0.25,
          tags: ['arabic_emphatic', 'twa'],
          description: 'അറബി ഗംഭീര ശബ്ദം Twa (ط)',
          condition: (ctx) => ctx.isEmphaticContext || ctx.hasTwaPattern
        }
      ],
      'ക': [
        {
          arabi: 'ک',
          baseWeight: 0.85,
          tags: ['dravidian_default', 'kaf'],
          description: 'സാധാരണ ദ്രാവിഡ Ka (ک)',
          condition: (ctx) => true
        },
        {
          arabi: 'ق',
          baseWeight: 0.15,
          tags: ['arabic_uvular', 'qaf'],
          description: 'അറബി താലവ്യ Qaf (ق)',
          condition: (ctx) => ctx.hasQafPattern || (ctx.isArabicOrigin && ctx.isUvularContext)
        }
      ],
      'ഖ': [
        {
          arabi: 'کَھ',
          baseWeight: 0.45,
          tags: ['dravidian_aspirate', 'kha'],
          description: 'മലയാള തനിമഹാപ്രാണ Kha (کَھ)',
          condition: (ctx) => !ctx.isArabicOrigin
        },
        {
          arabi: 'خ',
          baseWeight: 0.35,
          tags: ['arabic_velar', 'khaa'],
          description: 'അറബിക് ഉച്ചാരണം Khaa (خ)',
          condition: (ctx) => ctx.isArabicOrigin
        },
        {
          arabi: 'ق',
          baseWeight: 0.20,
          tags: ['arabic_qaf'],
          description: 'അറബി ഖഫ് (ق)',
          condition: (ctx) => ctx.hasQafPattern
        }
      ],
      'ഹ': [
        {
          arabi: 'ھ',
          baseWeight: 0.50,
          tags: ['dravidian_default', 'do_chashmi_heh'],
          description: 'സാധാരണ ദ്രാവിഡ ഹ (ھ)',
          condition: (ctx) => true
        },
        {
          arabi: 'ح',
          baseWeight: 0.35,
          tags: ['arabic_pharyngeal', 'haa'],
          description: 'അറബിക് ഹൽഖിയ്യായ Haa (ح)',
          condition: (ctx) => ctx.isArabicOrigin || ctx.hasHaaPattern
        },
        {
          arabi: 'ه',
          baseWeight: 0.15,
          tags: ['arabic_glottal_heh'],
          description: 'അറബി ഗ്ലോട്ടൽ Heh (ه)',
          condition: (ctx) => ctx.isArabicOrigin
        }
      ],
      'ദ': [
        {
          arabi: 'د',
          baseWeight: 0.70,
          tags: ['dravidian_default', 'dal'],
          description: 'സാധാരണ ദ്രാവിഡ ദ (د)',
          condition: (ctx) => true
        },
        {
          arabi: 'ذ',
          baseWeight: 0.15,
          tags: ['arabic_dhal'],
          description: 'അറബിക് ദാൽ/ദാൽ (ذ)',
          condition: (ctx) => ctx.isArabicOrigin && ctx.hasDhalPattern
        },
        {
          arabi: 'ض',
          baseWeight: 0.15,
          tags: ['arabic_dad'],
          description: 'അറബിക് ളാദ് (ض)',
          condition: (ctx) => ctx.isArabicOrigin && ctx.hasDadPattern
        }
      ],
      'ധ': [
        {
          arabi: 'دَھ',
          baseWeight: 0.85,
          tags: ['dravidian_aspirate', 'dha'],
          description: 'മലയാള തനിമഹാപ്രാണ Dha (دَھ)',
          condition: (ctx) => true
        },
        {
          arabi: 'ذ',
          baseWeight: 0.15,
          tags: ['arabic_dhal'],
          description: 'അറബി വായ്പാ പദങ്ങളിലെ ذ',
          condition: (ctx) => ctx.isArabicOrigin
        }
      ],
      'ശ': [
        {
          arabi: 'ش',
          baseWeight: 0.85,
          tags: ['sheen'],
          description: 'സാധാരണ ശ (ش)',
          condition: (ctx) => true
        },
        {
          arabi: 'ص',
          baseWeight: 0.15,
          tags: ['sad'],
          description: 'അറബി സ്വബാഹ് / സ്വാദ് പദങ്ങൾ (ص)',
          condition: (ctx) => ctx.isEmphaticContext
        }
      ],
      'ഷ': [
        {
          arabi: 'ۺ',
          baseWeight: 0.75,
          tags: ['mappila_retroflex_sha'],
          description: 'മാപ്പിള അറബി-മലയാളം ഷ (ۺ)',
          condition: (ctx) => true
        },
        {
          arabi: 'ش',
          baseWeight: 0.25,
          tags: ['sheen_variant'],
          description: 'അറബിക് ഷീൻ (ش)',
          condition: (ctx) => ctx.isArabicOrigin
        }
      ],
      'അ': [
        {
          arabi: 'اَ',
          baseWeight: 0.75,
          tags: ['dravidian_default_alif'],
          description: 'സാധാരണ ദ്രാവിഡ അ (اَ)',
          condition: (ctx) => !ctx.isAinWord
        },
        {
          arabi: 'عَ',
          baseWeight: 0.25,
          tags: ['arabic_ain'],
          description: 'അറബി ഐൻ (عَ) വായ്പാ പദങ്ങൾ',
          condition: (ctx) => ctx.isAinWord
        }
      ],
      'ആ': [
        {
          arabi: 'آ',
          baseWeight: 0.75,
          tags: ['dravidian_alif_madd'],
          description: 'സാധാരണ ആ (آ / اَا)',
          condition: (ctx) => !ctx.isAinWord
        },
        {
          arabi: 'عَا',
          baseWeight: 0.25,
          tags: ['arabic_ain_alif'],
          description: 'അറബി ഐൻ + അലിഫ് (عَا)',
          condition: (ctx) => ctx.isAinWord
        }
      ],
      'ഇ': [
        {
          arabi: 'اِ',
          baseWeight: 0.80,
          tags: ['dravidian_alif_kasrah'],
          description: 'സാധാരണ ഇ (اِ)',
          condition: (ctx) => !ctx.isAinWord
        },
        {
          arabi: 'عِ',
          baseWeight: 0.20,
          tags: ['arabic_ain_kasrah'],
          description: 'അറബി ഐൻ + കസ്‌റ് (عِ)',
          condition: (ctx) => ctx.isAinWord
        }
      ],
      'ഉ': [
        {
          arabi: 'اُ',
          baseWeight: 0.80,
          tags: ['dravidian_alif_dammah'],
          description: 'സാധാരണ ഉ (اُ)',
          condition: (ctx) => !ctx.isAinWord
        },
        {
          arabi: 'عُ',
          baseWeight: 0.20,
          tags: ['arabic_ain_dammah'],
          description: 'അറബി ഐൻ + ളമ്മ് (عُ)',
          condition: (ctx) => ctx.isAinWord
        }
      ],
      'ാ': [
        {
          arabi: 'َا',
          baseWeight: 0.90,
          tags: ['long_aa'],
          description: 'സാധാരണ ദീർഘ സ്വരം ാ (َا)',
          condition: (ctx) => true
        },
        {
          arabi: 'َى',
          baseWeight: 0.10,
          tags: ['alif_maqsura'],
          description: 'അറബി പദാവസാന അലിഫ് മഖ്സൂറ (َى)',
          condition: (ctx) => ctx.isWordFinal && ctx.isAlifMaqsuraPattern
        }
      ],
      'ജ': [
        {
          arabi: 'ج',
          baseWeight: 0.80,
          tags: ['standard_jim'],
          description: 'സാധാരണ ജിം (ج)',
          condition: (ctx) => true
        },
        {
          arabi: 'ز',
          baseWeight: 0.20,
          tags: ['arabic_zain'],
          description: 'അറബി സൈൻ (ز) വായ്പാ പദങ്ങൾ',
          condition: (ctx) => ctx.isArabicOrigin && ctx.hasZainPattern
        }
      ]
    },

    // Morphological Wazn & Authentic Name Patterns
    morphologicalPatterns: [
      {
        id: 'mustafa_pattern',
        name: "Mustaf'a / Mustafa Name Pattern (مُصْطَفَى)",
        regex: /^മുസ്തഫ([^\p{L}\p{M}]*)$/u,
        stem: 'മുസ്തഫ',
        resolvedArabi: 'مُصْطَفَى',
        priority: 100,
        description: 'മുസ്തഫ (Mustafa) എന്ന അറബി നാമം Sad + Twa + Alif Maqsura (مُصْطَفَى) രൂപത്തിൽ നിർണ്ണയിക്കുന്നു'
      },
      {
        id: 'fathima_pattern',
        name: "Fa'ila / Fathima Name Pattern (فَاطِمَة)",
        regex: /^ഫാത്തിമ([^\p{L}\p{M}]*)$/u,
        stem: 'ഫാത്തിമ',
        resolvedArabi: 'فَاطِمَة',
        priority: 100,
        description: 'ഫാത്തിമ എന്ന അറബിക് സ്ത്രീ നാമം (فَاطِمَة)'
      },
      {
        id: 'yusuf_pattern',
        name: 'Yusuf Name Pattern (يُوسُف)',
        regex: /^യൂസുഫ്([^\p{L}\p{M}]*)$/u,
        stem: 'യൂസുഫ്',
        resolvedArabi: 'يُوسُف',
        priority: 95,
        description: 'യൂസുഫ് എന്ന അറബി നാമം (يُوسُف)'
      },
      {
        id: 'abdullah_pattern',
        name: 'Abdullah Compound Name Pattern (عَبْدُ الله)',
        regex: /^അബ്ദുല്ല([^\p{L}\p{M}]*)$/u,
        stem: 'അബ്ദുല്ല',
        resolvedArabi: 'عَبْدُ الله',
        priority: 95,
        description: 'അബ്ദുല്ല എന്ന അറബിക് നാമം (عَبْدُ الله)'
      },
      {
        id: 'uthman_pattern',
        name: 'Uthman Name Pattern (عُثْمَان)',
        regex: /^ഉസ്മാൻ([^\p{L}\p{M}]*)$/u,
        stem: 'ഉസ്മാൻ',
        resolvedArabi: 'عُثْمَان',
        priority: 95,
        description: 'ഉസ്മാൻ എന്ന അറബി നാമം (عُثْمَان)'
      },
      {
        id: 'aisha_pattern',
        name: 'Aisha Name Pattern (عَائِشَة)',
        regex: /^ആയിഷ([^\p{L}\p{M}]*)$/u,
        stem: 'ആയിഷ',
        resolvedArabi: 'عَائِشَة',
        priority: 95,
        description: 'ആയിഷ എന്ന അറബി നാമം (عَائِشَة)'
      },
      {
        id: 'khadija_pattern',
        name: 'Khadija Name Pattern (خَدِيجَة)',
        regex: /^ഖദീജ([^\p{L}\p{M}]*)$/u,
        stem: 'ഖദീജ',
        resolvedArabi: 'خَدِيجَة',
        priority: 95,
        description: 'ഖദീജ എന്ന അറബി നാമം (خَدِيجَة)'
      },
      {
        id: 'ali_pattern',
        name: 'Ali Name Pattern (عَلِيّ)',
        regex: /^അലി([^\p{L}\p{M}]*)$/u,
        stem: 'അലി',
        resolvedArabi: 'عَلِيّ',
        priority: 95,
        description: 'അലി എന്ന അറബി നാമം (عَلِيّ)'
      },
      {
        id: 'umar_pattern',
        name: 'Umar Name Pattern (عُمَر)',
        regex: /^ഉമർ([^\p{L}\p{M}]*)$/u,
        stem: 'ഉമർ',
        resolvedArabi: 'عُمَر',
        priority: 95,
        description: 'ഉമർ എന്ന അറബി നാമം (عُمَر)'
      },
      {
        id: 'musa_pattern',
        name: 'Musa Name Pattern with Alif Maqsura (مُوسَى)',
        regex: /^മൂസാ([^\p{L}\p{M}]*)$/u,
        stem: 'മൂസാ',
        resolvedArabi: 'مُوسَى',
        priority: 95,
        description: 'മൂസാ എന്ന അറബി നാമം അലിഫ് മഖ്സൂറയോടെ (مُوسَى)'
      },
      {
        id: 'isa_pattern',
        name: 'Isa Name Pattern with Alif Maqsura (عِيسَى)',
        regex: /^ഈസാ([^\p{L}\p{M}]*)$/u,
        stem: 'ഈസാ',
        resolvedArabi: 'عِيسَى',
        priority: 95,
        description: 'ഈസാ എന്ന അറബി നാമം ഐൻ + അലിഫ് മഖ്സൂറയോടെ (عِيسَى)'
      },
      {
        id: 'yahya_pattern',
        name: 'Yahya Name Pattern with Alif Maqsura (يَحْيَى)',
        regex: /^യഹ്‌യ([^\p{L}\p{M}]*)$/u,
        stem: 'യഹ്‌യ',
        resolvedArabi: 'يَحْيَى',
        priority: 95,
        description: 'യഹ്‌യ എന്ന അറബി നാമം (يَحْيَى)'
      },
      {
        id: 'taqwa_pattern',
        name: 'Taqwa Pattern with Alif Maqsura (تَقْوَى)',
        regex: /^തഖ്‌വ([^\p{L}\p{M}]*)$/u,
        stem: 'തഖ്‌വ',
        resolvedArabi: 'تَقْوَى',
        priority: 90,
        description: 'തഖ്‌വ എന്ന പദം അലിഫ് മഖ്സൂറയോടെ (تَقْوَى)'
      },
      {
        id: 'thaha_pattern',
        name: 'Thaha Pattern (طٰهٰ)',
        regex: /^(?:ത്വാഹാ|താഹ)([^\p{L}\p{M}]*)$/u,
        stem: 'ത്വാഹാ',
        resolvedArabi: 'طٰهٰ',
        priority: 90,
        description: 'ത്വാഹാ / താഹ എന്ന വിശുദ്ധ നാമം (طٰهٰ)'
      },
      {
        id: 'yaseen_pattern',
        name: 'Yaseen Pattern (يٰسٓ)',
        regex: /^യാസീൻ([^\p{L}\p{M}]*)$/u,
        stem: 'യാസീൻ',
        resolvedArabi: 'يَاسِين',
        priority: 90,
        description: 'യാസീൻ എന്ന നാമം (يَاسِين)'
      }
    ],

    // Known word sets for linguistic context discrimination
    sanskritPhalaWords: new Set(['ഫലം', 'ഫണം', 'സഫലം', 'വിഫലം', 'അഫലം', 'നിഷ്ഫലം', 'ഫലകം', 'ഫലങ്ങൾ']),
    englishFaWords: new Set(['ഫുട്ബോൾ', 'ഫാൻ', 'ഫോൺ', 'ഫയൽ', 'ഫാക്ടറി', 'ഫോട്ടോ', 'ഫീസ്', 'ഫ്ലാറ്റ്', 'ഓഫീസ്', 'ഷെരീഫ്', 'ആരിഫ്', 'ഫ്രെയിം']),
    arabicAinWords: new Set([
      'അറബി', 'അലി', 'അബ്ദുല്ല', 'അബ്ദുൽ', 'അസീസ്', 'അദബ്', 'അഖീദ', 'അസ്വർ', 'അഫീഫ്', 'ആലിം', 'ആരിഫ്',
      'ആദിൽ', 'ആശൂറാ', 'ഇൽമ്', 'ഇസ്സത്ത്', 'ഇദ്ദ', 'ഇശാ', 'ഉമർ', 'ഉസ്മാൻ', 'ഉലമാ', 'ഉംറ', 'ഉദ്‌ഹിയ്യത്ത്'
    ]),
    nativeDravidianVowelWords: new Set([
      'അമ്മ', 'അകം', 'അരി', 'അപ്പൻ', 'അണ്ണൻ', 'അഴക്', 'അമ്പലം', 'അരുവി', 'അല', 'അട', 'അമ്പ്', 'ആന', 'ആട്',
      'ആറ്', 'ആമ', 'ഇല', 'ഇര', 'ഇരുട്ട്', 'ഇഞ്ചി', 'ഉറക്കം', 'ഉരൽ', 'ഉപ്പ്', 'ഉറുമ്പ്', 'എലി', 'ഏണി', 'ഒട്ടകം'
    ]),
    arabicEmphaticWords: new Set([
      'സ്വലാത്ത്', 'സ്വാദിഖ്', 'സ്വബർ', 'സ്വാലിഹ്', 'ബസ്വറ', 'മുസ്തഫ', 'നസ്വീഹത്ത്', 'സ്വുബ്ഹ്', 'ഖിസ്വാസ്', 'സദ്‌ഖ',
      'ത്വലാഖ്', 'ത്വവാഫ്', 'താഹിർ', 'താരിഖ്', 'ത്വബറാനി', 'ത്വാഹാ', 'സുൽത്താൻ', 'വത്വൻ', 'ഫർള്', 'റമളാൻ'
    ])
  };

  // Base Consonants Mapping (Consonant + inherent short a if standalone)
  const BASE_CONSONANTS = {
    'ക': 'ک',
    'ഖ': 'کَھ',
    'ഗ': 'گ',
    'ഘ': 'گَھ',
    'ങ': 'ۼ',
    'ച': 'چ',
    'ഛ': 'چَھ',
    'ജ': 'ج',
    'ഝ': 'جَھ',
    'ഞ': 'ڿ',
    'ട': 'ڊ',
    'ഠ': 'ڊَھ',
    'ഡ': 'ڗ',
    'ഢ': 'ڗَھ',
    'ണ': 'ڹ',
    'ത': 'ت',
    'ഥ': 'تَھ',
    'ദ': 'د',
    'ധ': 'دَھ',
    'ന': 'ن',
    'പ': 'پ',
    'ഫ': 'پَھ',
    'ബ': 'ب',
    'ഭ': 'بَھ',
    'മ': 'م',
    'യ': 'ي',
    'ര': 'ڔ',
    'ല': 'ل',
    'വ': 'و',
    'ശ': 'ش',
    'ഷ': 'ۺ',
    'സ': 'س',
    'ഹ': 'ھ',
    'ള': 'ۻ',
    'ഴ': 'ژ',
    'റ': 'ر'
  };

  const PURE_CONSONANT_STEMS = {
    'ക': 'ک',
    'ഖ': 'کھ',
    'ഗ': 'گ',
    'ഘ': 'گھ',
    'ങ': 'ۼ',
    'ച': 'چ',
    'ഛ': 'چھ',
    'ജ': 'ج',
    'ഝ': 'جھ',
    'ഞ': 'ڿ',
    'ട': 'ڊ',
    'ഠ': 'ڊھ',
    'ഡ': 'ڗ',
    'ഢ': 'ڗھ',
    'ണ': 'ڹ',
    'ത': 'ت',
    'ഥ': 'تھ',
    'ദ': 'د',
    'ധ': 'دھ',
    'ന': 'ن',
    'പ': 'پ',
    'ഫ': 'پھ',
    'ബ': 'ب',
    'ഭ': 'بھ',
    'മ': 'م',
    'യ': 'ي',
    'ര': 'ڔ',
    'ല': 'ل',
    'വ': 'و',
    'ശ': 'ش',
    'ഷ': 'ۺ',
    'സ': 'س',
    'ഹ': 'ھ',
    'ള': 'ۻ',
    'ഴ': 'ژ',
    'റ': 'ر'
  };

  const ASPIRATE_CONSONANTS = {
    'ഖ': 'کَھ',
    'ഘ': 'گَھ',
    'ഛ': 'چَھ',
    'ഝ': 'جَھ',
    'ഠ': 'ڊَھ',
    'ഢ': 'ڗَھ',
    'ഥ': 'تَھ',
    'ധ': 'دَھ',
    'ഫ': 'پَھ',
    'ഭ': 'بَھ'
  };

  const INDEPENDENT_VOWELS = {
    'അം': 'اَمْ',
    'അഃ': 'اَهْ',
    'അ': 'اَ',
    'ആ': 'آ',
    'ഇ': 'اِ',
    'ഈ': 'اِي',
    'ഉ': 'اُ',
    'ഊ': 'اُو',
    'ഋ': 'اْرْ',
    'എ': 'ا٘',
    'ഏ': 'ا٘ي',
    'ഐ': 'اَيْ',
    'ഒ': 'اٗ',
    'ഓ': 'اٗو',
    'ഔ': 'اَوْ'
  };

  const MATRA_MAP = {
    'ാ': 'َا',
    'ി': 'ِ',
    'ീ': 'ِي',
    'ു': 'ُ',
    'ൂ': 'ُو',
    'ൃ': 'ْرْ',
    'െ': '٘',
    'േ': '٘ي',
    'ൈ': 'َيْ',
    'ൊ': 'ٗ',
    'ോ': 'ٗو',
    'ൗ': 'َوْ',
    '്': 'ْ',
    'ം': 'َمْ',
    'ഃ': 'َهْ'
  };

  const CHILLU_MAP = {
    'ൻ': 'نْ',
    'ർ': 'رْ',
    'ൽ': 'لْ',
    'ൾ': 'ۻْ',
    'ൺ': 'ڹْ',
    'ൿ': 'کْ'
  };

  const SPECIAL_LIGATURES = {
    'ന്റെ': 'نْر٘',
    'ന്റ': 'نْرَ',
    'റ്റി': 'ڔِّ',
    'റ്റു': 'ڔُّ',
    'റ്റെ': 'ڔّ٘',
    'റ്റേ': 'ڔّ٘ي',
    'റ്റൊ': 'ڔّٗ',
    'റ്റോ': 'ڔّٗو',
    'റ്റാ': 'ڔَّا',
    'റ്റ്': 'ڔّْ',
    'റ്റ': 'ڔَّ',
    'ജ്ഞ': 'جْڿَ',
    'ക്ഷ': 'کْۺَ'
  };

  const NUMERALS = {
    '0': '٠', '1': '١', '2': '٢', '3': '٣', '4': '٤',
    '5': '٥', '6': '٦', '7': '٧', '8': '٨', '9': '٩',
    '൦': '٠', '൧': '١', '൨': '٢', '൩': '٣', '൪': '٤',
    '൫': '٥', '൬': '٦', '൭': '٧', '൮': '٨', '൯': '٩'
  };

  const REVERSE_NUMERALS = {
    '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
    '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9'
  };

  const ML_CONSONANTS_LIST = Object.keys(BASE_CONSONANTS);
  const ML_CONSONANTS_SET = new Set(ML_CONSONANTS_LIST);

  // High-frequency authentic vocabulary dictionary
  const LEXICAL_DICTIONARY = {
    'അറബി': 'عَرَبِ',
    'അറബികൾ': 'عَرَبِيکَۻْ',
    'അറബിയുടെ': 'عَرَبِيُڊ٘',
    'അറബിയിൽ': 'عَرَبِيِلْ',
    'അറബിക്': 'عَرَبِيکّْ',
    'അറബിയ്യ': 'عَرَبِيَّة',
    'അറബിയ്യത്ത്': 'عَرَبِيَّة',
    'മുസ്തഫ': 'مُصْطَفَى',
    'ഫാത്തിമ': 'فَاطِمَة',
    'അല്ലാഹു': 'اَلله',
    'അല്ലാഹുവിനെ': 'اَللهِوِن٘',
    'അല്ലാഹുവിൽ': 'اَللهِوِلْ',
    'അല്ലാഹുവിൻ': 'اَللهِوِنْ',
    'അല്ലാഹുവിലേക്ക്': 'اَللهِوِلَيکّْ',
    'ബിസ്മില്ലാഹിർറഹ്‌മാനിർറഹീം': 'بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيمِ',
    'ബിസ്മില്ലാഹിർറഹ്മാനിർറഹീം': 'بِسْمِ اللهِ الرَّحْمٰنِ الرَّحِيمِ',
    'ബിസ്മില്ലാഹ്': 'بِسْمِ اللهِ',
    'അൽഹംദുലില്ലാഹ്': 'اَلْحَمْدُ لِلّٰهِ',
    'സുബ്ഹാനല്ലാഹ്': 'سُبْحَانَ اللهِ',
    'ലാഇലാഹഇല്ലല്ലാഹ്': 'لَا إِلٰهَ إِلَّا الله',
    'അല്ലാഹുഅക്ബർ': 'اَللهُ اَكْبَر',
    'മാശാഅല്ലാഹ്': 'مَا شَاءَ الله',
    'ഇൻശാഅല്ലാഹ്': 'إِنْ شَاءَ الله',
    'റസൂൽ': 'رَسُول',
    'റസൂലുള്ളാഹ്': 'رَسُولُ اللهِ',
    'റസൂലിന്റെ': 'رَسُولِنْر٘',
    'നബി': 'نَبِيّ',
    'നബിയുടെ': 'نَبِيِّيُڊ٘',
    'നബിമാർ': 'نَبِيّمَاڔْ',
    'മുഹമ്മദ്': 'مُحَمَّد',
    'മുഹമ്മദ്‌': 'مُحَمَّدْ',
    'ഇബ്രാഹീം': 'إِبْرَاهِيم',
    'മൂസാ': 'مُوسَى',
    'ഈസാ': 'عِيسَى',
    'ആദം': 'آدَم',
    'ജിബ്‌രീൽ': 'جِبْرِيل',
    'മീഖാഈൽ': 'مِيكَائِيل',
    'ഇസ്റാഈൽ': 'إِسْرَائِيل',
    'മലക്ക്': 'مَلَكْ',
    'മലക്കുകൾ': 'مَلَکُّکَۻْ',
    'ഖുർആൻ': 'قُرْآن',
    'ഖുർആനിൽ': 'قُرْآنِلْ',
    'ഖുർആന്റെ': 'قُرْآنْر٘',
    'ഇസ്‌ലാം': 'اِسْلَام',
    'ഇസ്ലാം': 'اِسْلَام',
    'ഇസ്ലാമിക': 'اِسْلَامِيکَ',
    'മുസ്‌ലിം': 'مُسْلِم',
    'മുസ്ലിം': 'مُسْلِم',
    'മുസ്‌ലിമീങ്ങൾ': 'مُسْلِمِينْکَۻْ',
    'മുഅ്മിൻ': 'مُؤْمِن',
    'മുഅമിൻ': 'مُؤْمِن',
    'ഈമാൻ': 'إِيمَان',
    'ദുആ': 'دُعَاء',
    'ദുആഅ്': 'دُعَاء',
    'സലാം': 'سَلَام',
    'അസ്സലാമുഅലൈക്കും': 'اَلسَّلَامُ عَلَيْكُمْ',
    'വഅലൈകുമുസ്സലാം': 'وَعَلَيْكُمُ السَّلَام',
    'ഹജ്ജ്': 'حَجّ',
    'ഉംറ': 'عُمْرَة',
    'സിയാറത്ത്': 'زِيَارَة',
    'സിയാറത്തിന്': 'زِيَارَتِّنْ',
    'വഖ്ഫ്': 'وَقْف',
    'ബറകത്ത്': 'بَرَكَة',
    'ഖബർ': 'قَبْر',
    'ഖബ്ർ': 'قَبْر',
    'ഖബറുകൾ': 'قَبْرُکَۻْ',
    'മയ്യിത്ത്': 'مَيِّتْ',
    'ഫർള്': 'فَرْض',
    'വാജിബ്': 'وَاجِب',
    'വുളൂഅ്': 'وُضُوء',
    'വുളൂ': 'وُضُوء',
    'വുളു': 'وُضُوء',
    'സകാത്ത്': 'زَكَاة',
    'ഖിബ്‌ല': 'قِبْلَة',
    'ഖിബ്ല': 'قِبْلَة',
    'റമളാൻ': 'رَمَضَان',
    'മദ്റസ': 'مَدْرَسَة',
    'മദ്രസ': 'مَدْرَسَة',
    'മദ്റസകൾ': 'مَدْرَسَکَۻْ',
    'ഉസ്താദ്': 'اُسْتَاذ',
    'ഉസ്താദുമാർ': 'اُسْتَاذُمَاڔْ',
    'ആലിമ്': 'عَالِم',
    'ആലിം': 'عَالِم',
    'ഉലമാക്കൾ': 'عُلَمَاءکَّۻْ',
    'ഇൽമ്': 'عِلْم',
    'ഇമാം': 'اِمَام',
    'ഖുതുബ': 'خُطْبَة',
    'മൗലിദ്': 'مَوْلِد',
    'മൗലൂദ്': 'مَوْلُود',
    'ആമീൻ': 'آمِين',
    'സുബ്ഹ്': 'صُبْح',
    'ളുഹ്ർ': 'ظُهْر',
    'ളുഹ്ര്‍': 'ظُهْر',
    'അസ്വർ': 'عَصْر',
    'മഗ്‌രിബ്': 'مَغْرِب',
    'മഗ്രിബ്': 'مَغْرِب',
    'ഇശാ': 'عِشَاء',
    'ഇശാഅ്': 'عِشَاء',
    'തറാവീഹ്': 'تَرَاوِيح',
    'ജുമുഅ': 'جُمُعَة',
    'ജുമുഅത്ത്': 'جُمُعَة',
    'തൗബ': 'تَوْبَة',
    'സുന്നത്ത്': 'സُنَّة',
    'ബിദ്അത്ത്': 'بِدْعَة',
    'ഹറാം': 'حَرَام',
    'ഹലാൽ': 'حَلَال',
    'തക്ബീർ': 'تَكْبِير',
    'തസ്ബീഹ്': 'تَسْبِيح',
    'സ്വലാത്ത്': 'صَلَاة',
    'മിഹ്റാബ്': 'مِحْرَاب',
    'മിമ്പർ': 'مِنْبَر',
    'മുഅദ്ദിൻ': 'مُؤَذِّن',
    'ശഹാദത്ത്': 'شَهَادَة',
    'ബദ്ർ': 'بَدْر',
    'ഉഹുദ്': 'أُحُد',
    'ഹിജ്റ': 'هِجْرَة',
    'കഅ്ബ': 'كَعْبَة',
    'കഅബ': 'كَعْبَة',
    'ഖുതുബ്': 'قُطْب',
    'ഔലിയാ': 'أَوْلِيَاء',
    'ഔലിയാക്കൾ': 'أَوْلِيَاءکَّۻْ',
    'അദബ്': 'أَدَب',
    'അഖ്‌ലാഖ്': 'أَخْلَاق',
    'ഇഖ്‌ലാസ്': 'إِخْلَاص',
    'തവക്കുൽ': 'تَوَكُّل',
    'ശുക്ർ': 'شُكْر',
    'സ്വബ്ർ': 'صَبْر',
    'രിസ്ഖ്': 'رِزْق',
    'ഖദ്ർ': 'قَدْر',
    'ജന്നത്ത്': 'جَنَّة',
    'ജഹന്നം': 'جَهَنَّم',
    'നിക്കാഹ്': 'نِكَاح',
    'ത്വലാഖ്': 'طَلَاق',
    'മഹ്ർ': 'مَهْر',
    'ഇദ്ദ': 'عِدَّة',
    'ജീലാനി': 'جِيلَانِي',
    'രിഫാഈ': 'رِفَاعِي',
    'മുഹ്‌യിദ്ദീൻ': 'مُحْيِ الدِّين',
    'മുഹ്യുദ്ദീൻ': 'مُحْيِ الدِّين',
    'കുത്തുബിയ്യത്ത്': 'قُطْبِيَّة',
    'റാതീബ്': 'رَاتِيب',
    'ബൈത്ത്': 'بَيْت',
    'ഖസീദ': 'قَصِيدَة',
    'കിതാബ്': 'كِتَاب',
    'തഫ്സീർ': 'تَفْسِير',
    'ഹദീസ്': 'حَدِيث',
    'ഫിഖ്ഹ്': 'فِقْه',
    'അഖീദ': 'عَقِيدَة',
    'തസവ്വുഫ്': 'تَصَوُّف',
    'ത്വരീഖത്ത്': 'طَرِيقَة',
    // World Places, Countries, Capitals & Global Geography
    'ഇന്ത്യ': 'اِنْدِيَا',
    'ഭാരതം': 'بَھَاڔَتَمْ',
    'കേരളം': 'ک٘يڔَۻَمْ',
    'മലപ്പുറം': 'مَلَپُّرَمْ',
    'കോഴിക്കോട്': 'کٗوژِکّٗوڊْ',
    'കണ്ണൂർ': 'کَڹُّوڔْ',
    'കാസർഗോഡ്': 'کَاسَڔْگٗوڊْ',
    'വയനാട്': 'وَيَنَاڊْ',
    'പാലക്കാട്': 'پَالَکَّാڊْ',
    'തൃശ്ശൂർ': 'تْرِشُّوڔْ',
    'എറണാകുളം': 'ا٘ڔَڹَاکُۻَمْ',
    'ഇടുക്കി': 'اِڊُکِّ',
    'കോട്ടയം': 'کٗوڊَّيَمْ',
    'ആലപ്പുഴ': 'آلَپُّژَ',
    'പത്തനംതിട്ട': 'پَتَّنَمْتِڊَّ',
    'കൊല്ലം': 'کٗلَّمْ',
    'തിരുവനന്തപുരം': 'تِڔُوَنَنْتَپُڔَمْ',
    'പൊന്നാനി': 'پٗونَّانِ',
    'കൊച്ചി': 'کٗوچِّ',
    'ഡൽഹി': 'دِلْھِي',
    'ന്യൂഡൽഹി': 'نْيُودِلْھِي',
    'മുംബൈ': 'مُمْبَيْ',
    'കൊൽക്കത്ത': 'کٗلْکَّتَّ',
    'ചെന്നൈ': 'چ٘نَّيْ',
    'ബംഗളൂരു': 'بَمْگَۻُوڔُ',
    'ഹൈദരാബാദ്': 'حَيْدَرَابَاد',
    'മക്ക': 'مَكَّة',
    'മക്കത്തുൽമുകർറമ': 'مَكَّةُ الْمُكَرَّمَة',
    'മദീന': 'مَدِينَة',
    'മദീനത്തുൽമുനവ്വറ': 'اَلْمَدِينَةُ الْمُنَوَّرَة',
    'ജിദ്ദ': 'جِدَّة',
    'റിയാദ്': 'رِيَاض',
    'ത്വായിഫ്': 'طَائِف',
    'ഖുദ്സ്': 'قُدْس',
    'ബൈത്തുൽമുഖദ്ദസ്': 'بَيْتُ الْمَقْدِس',
    'ഫലസ്തീൻ': 'فِلَسْطِين',
    'ഫലസ്തീനിൽ': 'فِلَسْطِينِلْ',
    'ഈജിപ്ത്': 'مِصْر',
    'മിസ്ർ': 'مِصْر',
    'ഖാഹിറ': 'قَاهِرَة',
    'ബഗ്ദാദ്': 'بَغْدَاد',
    'ബാഗ്ദാദ്': 'بَغْدَاد',
    'ദമാസ്കസ്': 'دِمَشْق',
    'ശാം': 'شَام',
    'യമൻ': 'يَمَن',
    'ഹളർമൗത്ത്': 'حَضْرَمَوْت',
    'ഒമാൻ': 'عُمَان',
    'മസ്കറ്റ്': 'مَسْقَط',
    'കുവൈത്ത്': 'كُوَيْت',
    'ഖത്തർ': 'قَطَر',
    'ദോഹ': 'دَوْحَة',
    'ബഹ്റൈൻ': 'بَحْرَيْن',
    'മനാമ': 'مَنَامَة',
    'യുഎഇ': 'اَلْإِمَارَات',
    'ദുബായ്': 'دُبَيّ',
    'അബൂദാബി': 'أَبُو ظَبْي',
    'ഷാർജ': 'شَارِقَة',
    'അജ്മാൻ': 'عَجْمَان',
    'റാസൽഖൈമ': 'رَأْسُ الْخَيْمَة',
    'ഫുജൈറ': 'فُجَيْرَة',
    'ഉമ്മുൽഖുവൈൻ': 'أُمُّ الْقُيُوَيْن',
    'തുർക്കി': 'تُرْكِيَا',
    'ഇസ്താംബൂൾ': 'إِسْطَنْبُول',
    'അങ്കാറ': 'أَنْقَرَة',
    'ഇറാൻ': 'إِيرَان',
    'ടെഹ്റാൻ': 'طِهْرَان',
    'ഇറാഖ്': 'عِرَاق',
    'ബസ്വറ': 'بَصْرَة',
    'കൂഫ': 'كُوفَة',
    'കർബല': 'كَرْبَلَاء',
    'നജഫ്': 'نَجَف',
    'അഫ്ഗാനിസ്ഥാൻ': 'أَفْغَانِسْتَان',
    'കാബൂൾ': 'كَابُول',
    'പാകിസ്താൻ': 'پَاكِسْتَان',
    'ഇസ്ലാമാബാദ്': 'إِسْلَامْ آبَاد',
    'കറാച്ചി': 'كَرَاتْشِي',
    'ലാഹോർ': 'لَاهُور',
    'ബംഗ്ലാദേശ്': 'بَنْغْلَادِيش',
    'ധാക്ക': 'دَھَاکَّ',
    'മാലിദ്വീപ്': 'مَالْدِيف',
    'ശ്രീലങ്ക': 'سِرِيلَانْكَا',
    'കൊളംബോ': 'كُولُومْبُو',
    'നേപ്പാൾ': 'نِيبَال',
    'ഭൂട്ടാൻ': 'بُوتَان',
    'ചൈന': 'صِين',
    'ബീജിംഗ്': 'بِيجِينْغ',
    'റഷ്യ': 'رُوسِيَا',
    'മോസ്കോ': 'مُوسْكُو',
    'അമേരിക്ക': 'أَمْرِيكَا',
    'യുഎസ്എ': 'اَلْوِلَايَاتُ الْمُتَّحِدَة',
    'വാഷിംഗ്ടൺ': 'وَاشِنْطُن',
    'ന്യൂയോർക്ക്': 'نِيُويُورْك',
    'ലണ്ടൻ': 'لَنْدَن',
    'ബ്രിട്ടൻ': 'بِرِيطَانِيَا',
    'ഇംഗ്ലണ്ട്': 'إِنْجِلْتِرَا',
    'ഫ്രാൻസ്': 'فَرَنْسَا',
    'പാരിസ്': 'بَارِيس',
    'ജർമ്മനി': 'أَلْمَانِيَا',
    'ബെർലിൻ': 'بِرْلِين',
    'ഇറ്റലി': 'إِيطَالِيَا',
    'റോം': 'رُومَا',
    'സ്പെയിൻ': 'إِسْبَانِيَا',
    'അൻദലുസ്': 'أَنْدَلُس',
    'പോർച്ചുഗൽ': 'بُرْتُغَال',
    'ഗ്രീസ്': 'يُونَان',
    'യൂറോപ്പ്': 'أُورُوبَّا',
    'ആഫ്രിക്ക': 'إِفْرِيقِيَا',
    'ഏഷ്യ': 'آسِيَا',
    'ഓസ്ട്രേലിയ': 'أُسْتُرَالِيَا',
    'കാനഡ': 'كَنَدَا',
    'ബ്രസീൽ': 'بَرَازِيل',
    'അർജന്റീന': 'أَرْجَنْتِين',
    'മൊറോക്കോ': 'مَغْرِب',
    'അൽജീരിയ': 'جَزَائِر',
    'ടുണീഷ്യ': 'تُونِس',
    'ലിബിയ': 'لِيبِيَا',
    'സുഡാൻ': 'سُودَان',
    'സൊമാലിയ': 'صُومَال',
    'നൈജീരിയ': 'نَيْجِيرِيَا',
    'ദക്ഷിണാഫ്രിക്ക': 'جَنُوبُ إِفْرِيقِيَا',
    'ഇന്തോനേഷ്യ': 'إِنْدُونِيسِيَا',
    'ജക്കാർത്ത': 'جَاكَرْتَا',
    'മലേഷ്യ': 'مَالِيزِيَا',
    'ക്വാലാലംപൂർ': 'كُوَالَالَمْبُور',
    'സിംഗപ്പൂർ': 'سِنْغَافُورَة',
    'തായ്‌ലാൻഡ്': 'تَايْلَانْد',
    'ബാങ്കോക്ക്': 'بَانْكُوك',
    'ജപ്പാൻ': 'يَابَان',
    'ടോക്കിയോ': 'طُوكِيُو',
    'ദക്ഷിണകൊറിയ': 'كُورِيَا الْجَنُوبِيَّة',
    'സിയോൾ': 'سِيُول'
  };

  const LEXICAL_KEYS_SORTED = Object.keys(LEXICAL_DICTIONARY)
    .sort((a, b) => b.length - a.length);

  // Ambiguity entries for interactive selection
  const AMBIGUOUS_WORDS = {
    'സലാം': {
      candidates: ['سَلَام', 'سَلَامْ'],
      reason: 'അറബി പദമായ സലാം (سَلَام) അല്ലെങ്കിൽ ഫോണറ്റിക് ലിപിമാറ്റം (سَلَامْ)'
    },
    'ഖബർ': {
      candidates: ['قَبْر', 'کَھبَڔْ'],
      reason: 'അറബി മൂലം (قَبْر) അല്ലെങ്കിൽ അറബി-മലയാള ഫോണറ്റിക് (کَھبَڔْ)'
    },
    'സ്വലാത്ത്': {
      candidates: ['صَلَاة', 'صَلَاتْ'],
      reason: 'ക്ലാസിക്കൽ അറബിക് തഅ് മർബൂത (صَلَاة) അല്ലെങ്കിൽ മാപ്പിള ലിപിയിലെ തഅ് (صَلَاتْ)'
    },
    'സൂറത്ത്': {
      candidates: ['സൂറത്ത്' === 'സൂറത്ത്' ? 'سُورَة' : 'سُوڔَتْ', 'سُوڔَتْ'],
      reason: 'ഖുർആനിലെ സൂറത്ത് (سُورَة) അല്ലെങ്കിൽ മുഖം/നഗരം എന്ന അർത്ഥത്തിലുള്ള സൂറത്ത് (سُوڔَتْ)'
    },
    'മദ്റസ': {
      candidates: ['مَدْرَسَة', 'مَدْڔَسَ'],
      reason: 'അറബി രൂപം (مَدْرَسَة) അല്ലെങ്കിൽ പ്രാദേശിക ഉച്ചാരണ രൂപം (مَدْڔَسَ)'
    },
    'ഹാജി': {
      candidates: ['حَاجِي', 'ھَاجِي'],
      reason: 'അറബിക് ഹാഅ് (حَاجِي) അല്ലെങ്കിൽ ഫോണറ്റിക് ഹ (ھَاجِي)'
    }
  };

  // Reverse base consonants table
  const ARABI_BASE_CONSONANTS = {
    'کَھ': 'ഖ', 'گَھ': 'ഘ', 'چَھ': 'ഛ', 'ചَھ': 'ഛ', 'جَھ': 'ഝ', 'ജَھ': 'ഝ',
    'ڊَھ': 'ഠ', 'ڗَھ': 'ഢ', 'തَھ': 'ഥ', 'تَھ': 'ഥ', 'ദَھ': 'ധ', 'دَھ': 'ധ',
    'پَھ': 'ഫ', 'ബَھ': 'ഭ', 'بَھ': 'ഭ',
    'نْتَھ': 'ന്ഥ', 'نْدَھ': 'ന്ധ', 'ڹْڊَھ': 'ണ്ഠ', 'ڹْڗَھ': 'ണ്ഢ',
    'سْتَھ': 'സ്ഥ', 'സْتَھ': 'സ്ഥ', 'سْپَھ': 'സ്ഫ', 'സْپَھ': 'സ്ഫ',
    'ۺْڊَھ': 'ഷ്ഠ',
    'نْتھ': 'ന്ഥ', 'نْدھ': 'ന്ധ', 'نْت': 'ന്ത', 'نْد': 'ന്ദ',
    'ڹْڊھ': 'ണ്ഠ', 'ڹْڗھ': 'ണ്ഢ', 'ڹْڊ': 'ണ്ട', 'ڹْڗ': 'ണ്ഡ',
    'ۼْک': 'ങ്ക', 'ڿْچ': 'ഞ്ച', 'ڿْج': 'ഞ്ജ', 'مْب': 'മ്പ', 'مْپ': 'മ്പ',
    'کْۺ': 'ക്ഷ', 'جْڿ': 'ജ്ഞ', 'سْتھ': 'സ്ഥ', 'سْپھ': 'സ്ഫ',
    'ۺْڊھ': 'ഷ്ഠ', 'ۺْڹ': 'ഷ്ണ', 'ۺْڊ': 'ഷ്ട',
    'کھ': 'ഖ', 'گھ': 'ഘ', 'چھ': 'ഛ', 'جھ': 'ഝ',
    'ڊھ': 'ഠ', 'ڗھ': 'ഢ', 'تھ': 'ഥ', 'دھ': 'ധ',
    'پھ': 'ഫ', 'بھ': 'ഭ',
    'کَه': 'ഖ', 'گَه': 'ഘ', 'ചَه': 'ഛ', 'ജَه': 'ഝ',
    'ڊَه': 'ഠ', 'ڗَه': 'ഢ', 'തَه': 'ഥ', 'ദَه': 'ധ',
    'پَه': 'ഫ', 'ബَه': 'ഭ',
    'که': 'ഖ', 'گه': 'ഘ', 'چه': 'ഛ', 'جه': 'ഝ',
    'ڊه': 'ഠ', 'ڗه': 'ഢ', 'ته': 'ഥ', 'ده': 'ധ',
    'په': 'ഫ', 'به': 'ഭ',
    'ک': 'ക', 'ك': 'ക', 'گ': 'ഗ', 'ۼ': 'ങ', 'ڠ': 'ങ',
    'ച': 'ച', 'چ': 'ച', 'ജ': 'ജ', 'ج': 'ജ',
    'ڿ': 'ഞ', 'ڽ': 'ഞ', 'ڊ': 'ട', 'ٹ': 'ട',
    'ڗ': 'ഡ', 'ڈ': 'ഡ', 'ڹ': 'ണ', 'ڻ': 'ണ',
    'ത': 'ത', 'ت': 'ത', 'ദ': 'ദ', 'د': 'ദ',
    'ന': 'ന', 'ن': 'ന', 'പ': 'പ', 'پ': 'പ',
    'ബ': 'ബ', 'ب': 'ബ', 'മ': 'മ', 'م': 'മ',
    'യ': 'യ', 'ي': 'യ', 'ى': 'യ', 'ی': 'യ',
    'ڔ': 'ര', 'ല': 'ല', 'ل': 'ല', 'വ': 'വ', 'و': 'വ',
    'ശ': 'ശ', 'ش': 'ശ', 'ഷ': 'ഷ', 'ۺ': 'ഷ',
    'സ': 'സ', 'س': 'സ', 'ഹ': 'ഹ', 'ھ': 'ഹ', 'ه': 'ഹ', 'ة': 'ത്',
    'ള': 'ള', 'ۻ': 'ള', 'ڸ': 'ള', 'ഴ': 'ഴ', 'ژ': 'ഴ',
    'റ': 'റ', 'ر': 'റ',
    'ع': 'അ', 'ط': 'ത', 'ظ': 'ള', 'ص': 'സ', 'ض': 'ള',
    'ذ': 'ദ', 'ث': 'സ', 'ح': 'ഹ', 'خ': 'ഖ', 'غ': 'ഗ', 'ق': 'ഖ', 'ف': 'ഫ'
  };

  const ARABI_CONSONANTS_SORTED = Object.keys(ARABI_BASE_CONSONANTS)
    .sort((a, b) => b.length - a.length);

  const ARABI_LIGATURES_TO_ML = {
    'نْر٘': 'ന്റെ', 'نْرَ': 'ന്റ', 'نْر': 'ന്റ',
    'ڔّْ': 'റ്റ്', 'ڔَّا': 'റ്റാ', 'ڔِّ': 'റ്റി', 'ڔِّي': 'റ്റീ',
    'ڔُّ': 'റ്റു', 'ڔُّو': 'റ്റൂ', 'ڔّ٘': 'റ്റെ', 'ڔّ٘ي': 'റ്റേ',
    'ڔّٗ': 'റ്റൊ', 'ڔّٗو': 'റ്റോ', 'ڔَّ': 'റ്റ', 'ڔّ': 'റ്റ', 'رّ': 'റ്റ',
    'جْڿَ': 'ജ്ഞ', 'جْڿ': 'ജ്ഞ', 'کْۺَ': 'ക്ഷ', 'کْۺ': 'ക്ഷ'
  };

  const ARABI_LIGATURES_SORTED = Object.keys(ARABI_LIGATURES_TO_ML)
    .sort((a, b) => b.length - a.length);

  const ARABI_INDEPENDENT_VOWELS = {
    'اَمْ': 'അം', 'اَمۡ': 'അം', 'اَهْ': 'അഃ',
    'اَ': 'അ', 'آ': 'ആ', 'اَا': 'ആ', 'اِ': 'ഇ', 'اِي': 'ഈ',
    'اُ': 'ഉ', 'اُو': 'ഊ', 'اْرْ': 'ഋ', 'ا٘': 'എ', 'ا٘ي': 'ഏ',
    'اَيْ': 'ഐ', 'اٗ': 'ഒ', 'اٗو': 'ഓ', 'اَوْ': 'ഔ',
    'إِ': 'ഇ', 'إِي': 'ഈ', 'أُ': 'ഉ', 'أَ': 'അ',
    'عَ': 'അ', 'عَا': 'ആ', 'عِ': 'ഇ', 'عِي': 'ഈ', 'عُ': 'ഉ', 'عُو': 'ഊ'
  };

  const ARABI_INDEP_VOWELS_SORTED = Object.keys(ARABI_INDEPENDENT_VOWELS)
    .sort((a, b) => b.length - a.length);

  const ARABI_MATRAS_TO_ML = {
    'َّوْ': 'ൗ', 'َّيْ': 'ൈ', 'ّٗو': 'ോ', 'ّ٘ي': 'േ',
    'ِّي': 'ീ', 'ُّو': 'ൂ', 'ّْرْ': 'ൃ', 'َّمْ': 'ം',
    'َّهْ': 'ഃ', 'َّا': 'ാ', 'ِّ': 'ി', 'ُّ': 'ു',
    'ّ٘': 'െ', 'ّٗ': 'ൊ', 'ّْ': '്', 'َّ': '',
    'َوْ': 'ൗ', 'َيْ': 'ൈ', 'ٗو': 'ോ', '٘ي': 'േ',
    'ِي': 'ീ', 'ُو': 'ൂ', 'ْرْ': 'ൃ', 'َمْ': 'ം',
    'َمۡ': 'ം', 'َهْ': 'ഃ', 'َا': 'ാ', 'ِ': 'ി',
    'ُ': 'ു', '٘': 'െ', 'ٗ': 'ൊ', 'ْ': '്',
    'ۡ': '്', 'مْ': 'ം', 'مۡ': 'ം', 'هْ': 'ഃ',
    'ً': 'ം', 'ٍ': 'ിൻ', 'ٌ': 'ുൻ', 'ٰ': 'ാ',
    'َى': 'ാ', 'َ': ''
  };

  const ARABI_MATRAS_SORTED = Object.keys(ARABI_MATRAS_TO_ML)
    .sort((a, b) => b.length - a.length);

  const ARABI_CHILLUS_TO_ML = {
    'نْ': 'ൻ', 'نۡ': 'ൻ', 'رْ': 'ർ', 'رۡ': 'ർ',
    'لْ': 'ൽ', 'لۡ': 'ൽ', 'ۻْ': 'ൾ', 'ۻۡ': 'ൾ',
    'ڹْ': 'ൺ', 'ڹۡ': 'ൺ', 'کْ': 'ൿ', 'کۡ': 'ൿ'
  };

  const REVERSE_LEXICAL_DICTIONARY = {};
  for (const [ml, ar] of Object.entries(LEXICAL_DICTIONARY)) {
    if (!REVERSE_LEXICAL_DICTIONARY[ar]) {
      REVERSE_LEXICAL_DICTIONARY[ar] = ml;
    }
  }

  // =========================================================================
  // 2. NORMALIZATION & TOKENIZATION
  // =========================================================================

  /**
   * Unicode canonical normalization with decomposed chillu and ZWNJ repair
   */
  function normalizeMalayalam(text) {
    if (!text) return '';
    let norm = text.normalize('NFC');
    norm = norm
      .replace(/\u0D28\u0D4D\u200D/g, 'ൻ')
      .replace(/\u0D30\u0D4D\u200D/g, 'ർ')
      .replace(/\u0D32\u0D4D\u200D/g, 'ൽ')
      .replace(/\u0D33\u0D4D\u200D/g, 'ൾ')
      .replace(/\u0D23\u0D4D\u200D/g, 'ൺ')
      .replace(/\u0D15\u0D4D\u200D/g, 'ൿ')
      .replace(/ു്/g, '്')
      .replace(/\u0D4D\u200C/g, '്'); // Normalize ZWNJ after virama (ഇസ്‌ലാം -> ഇസ്ലാം)

    return norm;
  }

  /**
   * Decomposes a Malayalam word into linguistic syllables with position tags
   */
  function segmentMalayalamWord(word) {
    const syllables = [];
    const len = word.length;
    let i = 0;

    while (i < len) {
      const char = word[i];
      const startIdx = i;

      // Special ligature check
      let matchedLig = null;
      for (const lig of Object.keys(SPECIAL_LIGATURES)) {
        if (word.startsWith(lig, i)) {
          matchedLig = lig;
          break;
        }
      }
      if (matchedLig) {
        syllables.push({
          raw: matchedLig,
          type: 'ligature',
          onset: matchedLig,
          nucleus: '',
          coda: ''
        });
        i += matchedLig.length;
        continue;
      }

      // Chillu
      if (CHILLU_MAP[char]) {
        syllables.push({
          raw: char,
          type: 'chillu',
          onset: '',
          nucleus: '',
          coda: char
        });
        i++;
        continue;
      }

      // Independent Vowel
      const two = word.substring(i, i + 2);
      if (INDEPENDENT_VOWELS[two]) {
        syllables.push({
          raw: two,
          type: 'independent_vowel',
          onset: '',
          nucleus: two,
          coda: ''
        });
        i += 2;
        continue;
      }
      if (INDEPENDENT_VOWELS[char]) {
        syllables.push({
          raw: char,
          type: 'independent_vowel',
          onset: '',
          nucleus: char,
          coda: ''
        });
        i++;
        continue;
      }

      // Consonant + cluster / matra
      if (ML_CONSONANTS_SET.has(char)) {
        const c1 = char;

        // Geminate or conjunct (C1 + ് + C2)
        if (i + 1 < len && word[i + 1] === '്' && i + 2 < len && ML_CONSONANTS_SET.has(word[i + 2])) {
          const c2 = word[i + 2];
          let nextIdx = i + 3;
          let matra = '';
          if (nextIdx < len && MATRA_MAP[word[nextIdx]]) {
            matra = word[nextIdx];
            nextIdx++;
          }
          let coda = '';
          if (nextIdx < len && (word[nextIdx] === 'ം' || word[nextIdx] === 'ഃ')) {
            coda = word[nextIdx];
            nextIdx++;
          }

          const rawSyl = word.substring(startIdx, nextIdx);
          syllables.push({
            raw: rawSyl,
            type: c1 === c2 ? 'geminate' : 'conjunct',
            onset: c1 + '്' + c2,
            nucleus: matra || 'a',
            coda: coda
          });
          i = nextIdx;
          continue;
        }

        // Single consonant with or without matra
        let nextIdx = i + 1;
        let matra = '';
        if (nextIdx < len && MATRA_MAP[word[nextIdx]]) {
          matra = word[nextIdx];
          nextIdx++;
        }
        let coda = '';
        if (nextIdx < len && (word[nextIdx] === 'ം' || word[nextIdx] === 'ഃ')) {
          coda = word[nextIdx];
          nextIdx++;
        }

        const rawSyl = word.substring(startIdx, nextIdx);
        syllables.push({
          raw: rawSyl,
          type: 'consonant_syllable',
          onset: c1,
          nucleus: matra || 'a',
          coda: coda
        });
        i = nextIdx;
        continue;
      }

      // Other symbol
      syllables.push({
        raw: char,
        type: 'other',
        onset: '',
        nucleus: '',
        coda: ''
      });
      i++;
    }

    // Assign positional tags (initial, medial, final)
    const total = syllables.length;
    syllables.forEach((s, idx) => {
      s.isInitial = idx === 0;
      s.isFinal = idx === total - 1;
      s.isMedial = !s.isInitial && !s.isFinal;
      s.index = idx;
    });

    return syllables;
  }

  // =========================================================================
  // 3. CONTEXT EXTRACTOR & MORPHOLOGICAL CLASSIFIER
  // =========================================================================

  /**
   * Extracts linguistic context features from a word to inform candidate scoring
   */
  function extractWordContext(word) {
    const clean = word.replace(/[^\p{L}\p{M}]/gu, '');
    const isSanskritPhala = LINGUISTIC_KNOWLEDGE_BASE.sanskritPhalaWords.has(clean);
    const isEnglishFa = LINGUISTIC_KNOWLEDGE_BASE.englishFaWords.has(clean);
    const isAinWord = LINGUISTIC_KNOWLEDGE_BASE.arabicAinWords.has(clean);
    const isDravidianNative = LINGUISTIC_KNOWLEDGE_BASE.nativeDravidianVowelWords.has(clean);
    const isEmphaticWord = LINGUISTIC_KNOWLEDGE_BASE.arabicEmphaticWords.has(clean);
    const isKnownLexical = !!LEXICAL_DICTIONARY[clean];

    // Morphological pattern match
    let matchedPattern = null;
    for (const pat of LINGUISTIC_KNOWLEDGE_BASE.morphologicalPatterns) {
      if (pat.regex.test(clean)) {
        matchedPattern = pat;
        break;
      }
    }

    // Heuristic indicators of Arabic loan origin
    const containsArabicMarkers =
      isKnownLexical ||
      matchedPattern ||
      clean.includes('ഖുർ') ||
      clean.includes('അബ്ദു') ||
      clean.includes('റഹ്മ്') ||
      clean.includes('മുസ്ത്') ||
      clean.includes('ഫർ') ||
      clean.includes('വുളൂ') ||
      clean.includes('സകാ') ||
      clean.includes('ഹജ്ജ്') ||
      clean.includes('നബി') ||
      clean.includes('റസൂ') ||
      clean.endsWith('ഉദ്ദീൻ') ||
      clean.endsWith('ിയ്യത്ത്') ||
      clean.endsWith('അത്ത്');

    const isArabicOrigin = (containsArabicMarkers || isAinWord || isEmphaticWord) && !isDravidianNative && !isSanskritPhala;

    return {
      word: clean,
      isArabicOrigin,
      isSanskritPhala,
      isEnglishLoan: isEnglishFa,
      isAinWord,
      isDravidianNative,
      isEmphaticContext: isEmphaticWord || clean.includes('ത്വ') || clean.includes('സ്വ'),
      isAlifMaqsuraPattern: clean === 'മുസ്തഫ' || clean === 'മൂസാ' || clean === 'ഈസാ' || clean === 'യഹ്‌യ' || clean === 'തഖ്‌വ',
      matchedPattern,
      hasFaPattern: isArabicOrigin || isEnglishFa || (clean.startsWith('ഫ') && !isSanskritPhala),
      hasSadPattern: clean.includes('സ്വ') || isEmphaticWord || clean.includes('മുസ്തഫ'),
      hasTwaPattern: clean.includes('ത്വ') || clean.includes('മുസ്തഫ') || clean.includes('സുൽത്താൻ'),
      hasQafPattern: clean.includes('ഖുർ') || clean.includes('ഖിബ്') || clean.includes('തഖ്') || clean.includes('ഖാസിം'),
      hasHaaPattern: clean.includes('ഹജ്ജ്') || clean.includes('ഹലാൽ') || clean.includes('ഹറാം') || clean.includes('അഹമ്മദ്'),
      hasDhalPattern: clean.includes('ദിക്‌ർ') || clean.includes('മുഅദ്ദിൻ') || clean.includes('ഉസ്താദ്'),
      hasDadPattern: clean.includes('റമളാൻ') || clean.includes('ഫർള്') || clean.includes('വുളൂ'),
      hasThaPattern: clean.includes('സാബിത്') || clean.includes('ഉസ്മാൻ') || clean.includes('ഹദീസ്'),
      hasZainPattern: clean.includes('സകരിയ്യ') || clean.includes('സൈനബ്') || clean.includes('സിയാറത്ത്')
    };
  }

  // =========================================================================
  // 4. MULTI-CANDIDATE GENERATOR & SCORING RANKER
  // =========================================================================

  /**
   * Generates candidate transliterations for a single syllable and ranks them
   */
  function scoreSyllableCandidates(syllable, wordContext) {
    const candidates = [];
    const raw = syllable.raw;

    // 1. Check if the onset matches ambiguous candidate rules
    const isConjunctCluster = syllable.type === 'conjunct';
    const targetOnset = syllable.onset.replace(/്.*/, ''); // e.g. ഫ in ഫ്, or സ in സ്ത
    const ambiguousRules = !isConjunctCluster ? (LINGUISTIC_KNOWLEDGE_BASE.candidates[targetOnset] ||
                           (syllable.type === 'independent_vowel' ? LINGUISTIC_KNOWLEDGE_BASE.candidates[syllable.nucleus] : null)) : null;

    if (ambiguousRules) {
      ambiguousRules.forEach(rule => {
        let score = rule.baseWeight * 100;
        const reasons = [`അടിസ്ഥാന വെയിറ്റ് (${(rule.baseWeight * 100).toFixed(0)})`];

        // Evaluate condition
        const conditionPass = rule.condition(wordContext);
        if (conditionPass) {
          score += 40;
          reasons.push('ലിംഗ്വിസ്റ്റിക് കണ്ടീഷൻ പാസ്സായി (+40)');
        } else {
          score -= 30;
          reasons.push('ലിംഗ്വിസ്റ്റിക് കണ്ടീഷൻ യോജിച്ചില്ല (-30)');
        }

        // Special contextual heuristics
        if (targetOnset === 'ഫ' && rule.arabi === 'ف' && wordContext.hasFaPattern) {
          score += 50;
          reasons.push('അറബി/വായ്പാപദ വസൻ Fa (ف) മാച്ച് (+50)');
        }
        if (targetOnset === 'ഫ' && rule.arabi === 'پَھ' && wordContext.isSanskritPhala) {
          score += 70;
          reasons.push('സംസ്കൃത/ദ്രാവിഡ തനിപദ Pha (پَھ) മാച്ച് (+70)');
        }
        if (targetOnset === 'സ' && rule.arabi === 'ص' && wordContext.hasSadPattern) {
          score += 45;
          reasons.push('Sad (ص) ഗംഭീര ശബ്ദ പരിസരം (+45)');
        }
        if (targetOnset === 'ത' && rule.arabi === 'ط' && wordContext.hasTwaPattern) {
          score += 45;
          reasons.push('Twa (ط) ഗംഭീര ശബ്ദ പരിസരം (+45)');
        }

        // Construct Arabic syllable surface form
        let arabiSurface = '';
        if (syllable.type === 'geminate') {
          arabiSurface = rule.arabi + 'ّ' + (MATRA_MAP[syllable.nucleus] || 'َ');
        } else if (syllable.type === 'independent_vowel') {
          arabiSurface = rule.arabi;
        } else {
          const matra = syllable.nucleus === 'a' ? (rule.arabi.includes('َ') ? '' : 'َ') : (MATRA_MAP[syllable.nucleus] || '');
          arabiSurface = rule.arabi + matra;
        }

        if (syllable.coda) {
          arabiSurface += (syllable.coda === 'ം' ? 'مْ' : 'هْ');
        }

        candidates.push({
          arabi: arabiSurface,
          baseArabi: rule.arabi,
          score,
          tags: rule.tags,
          description: rule.description,
          reasons
        });
      });
    }

    // Baseline fallback candidate using verified phonetic engine
    const baselineSurface = transliterateMalayalamToken(raw);
    const hasBaselineAlready = candidates.some(c => c.arabi === baselineSurface);
    if (!hasBaselineAlready) {
      candidates.push({
        arabi: baselineSurface,
        baseArabi: baselineSurface,
        score: 60,
        tags: ['baseline_phonetic'],
        description: 'സ്റ്റാൻഡേർഡ് ലിപി നിയമം',
        reasons: ['ഫൊണറ്റിക് അടിസ്ഥാന ലിപി (+60)']
      });
    }

    // Sort descending by score
    candidates.sort((a, b) => b.score - a.score);
    return candidates;
  }

  /**
   * Word-level Transliteration & Candidate Ranker
   */
  function transliterateWordWithAI(word, options = {}) {
    if (!word) return { text: '', candidates: [], trace: null };

    const norm = normalizeMalayalam(word);
    const wordContext = extractWordContext(norm);

    // 1. Direct Morphological Wazn / Name Pattern Check
    if (wordContext.matchedPattern) {
      const pat = wordContext.matchedPattern;
      const resolved = pat.resolvedArabi;
      const trace = {
        input: word,
        normalized: norm,
        graphemes: Array.from(norm),
        detectedPhonemes: segmentMalayalamWord(norm),
        candidateMappings: [{ phoneme: norm, candidates: [{ arabi: resolved, score: 200, rule: pat.name }] }],
        appliedLinguisticRules: [
          `അറബി നാമ/വസൻ പാറ്റേൺ: ${pat.name}`,
          pat.description
        ],
        candidateScores: [
          { arabi: resolved, score: 200, probability: '100%', breakdown: [pat.description] }
        ],
        selectedArabi: resolved,
        method: 'morphological_pattern'
      };
      return { text: resolved, candidates: [resolved], trace };
    }

    // 2. Direct Lexical Dictionary Check
    if (LEXICAL_DICTIONARY[norm]) {
      const lex = LEXICAL_DICTIONARY[norm];
      const trace = {
        input: word,
        normalized: norm,
        graphemes: Array.from(norm),
        detectedPhonemes: segmentMalayalamWord(norm),
        candidateMappings: [{ phoneme: norm, candidates: [{ arabi: lex, score: 180, rule: 'Lexical Match' }] }],
        appliedLinguisticRules: [
          'അധികൃത അറബി-മലയാളം നിഘണ്ടു പദം (Lexical Dictionary Match)',
          `അധികൃത രൂപം: ${norm} → ${lex}`
        ],
        candidateScores: [
          { arabi: lex, score: 180, probability: '98%', breakdown: ['അധികൃത നിഘണ്ടു പദം (+180)'] }
        ],
        selectedArabi: lex,
        method: 'lexical_dictionary'
      };
      return { text: lex, candidates: [lex], trace };
    }

    // 3. Segment into Syllables and Generate Multiple Candidate Hypotheses
    const syllables = segmentMalayalamWord(norm);
    const syllableCandidateMatrix = syllables.map(s => scoreSyllableCandidates(s, wordContext));

    // Form word hypotheses by beam composition of syllable candidates
    let wordHypotheses = [{ arabi: '', score: 0, steps: [] }];
    for (let sIdx = 0; sIdx < syllableCandidateMatrix.length; sIdx++) {
      const sylCands = syllableCandidateMatrix[sIdx];
      const nextWordHypotheses = [];

      for (const parent of wordHypotheses) {
        for (const cand of sylCands) {
          nextWordHypotheses.push({
            arabi: parent.arabi + cand.arabi,
            score: parent.score + cand.score,
            steps: parent.steps.concat({
              syllable: syllables[sIdx].raw,
              selected: cand.arabi,
              score: cand.score,
              description: cand.description,
              reasons: cand.reasons
            })
          });
        }
      }

      // Beam prune top 5
      nextWordHypotheses.sort((a, b) => b.score - a.score);
      wordHypotheses = nextWordHypotheses.slice(0, 5);
    }

    // Applied linguistic rules list
    const appliedRules = [];
    if (wordContext.isArabicOrigin) {
      appliedRules.push('അറബിക് വായ്പാപദ സ്വഭാവം നിർണ്ണയിക്കപ്പെട്ടു (Arabic loanword origin detected)');
    }
    if (wordContext.isAinWord) {
      appliedRules.push('അറബിക് ഐൻ (ع) സ്വര പദാവലിയിൽ ഉൾപ്പെട്ടിരിക്കുന്നു (Ain root match)');
    }
    if (wordContext.isSanskritPhala) {
      appliedRules.push('സംസ്കൃത/ദ്രാവിഡ തനിപദ Pha (پَھ) സ്വഭാവം നിർണ്ണയിക്കപ്പെട്ടു');
    }
    if (wordContext.isEnglishLoan) {
      appliedRules.push('ഇംഗ്ലീഷ്/ആധുനിക വായ്പാപദ Fa (ف) സ്വഭാവം നിർണ്ണയിക്കപ്പെട്ടു');
    }
    if (wordContext.isEmphaticContext) {
      appliedRules.push('ഗംഭീര അക്ഷര പരിസരം (Emphatic context: Sad/Twa detected)');
    }
    if (wordContext.isAlifMaqsuraPattern) {
      appliedRules.push('അലിഫ് മഖ്സൂറ പദാവസാന നിയമം ബാധകമാക്കി (Alif Maqsura rule fired)');
    }
    if (appliedRules.length === 0) {
      appliedRules.push('സാധാരണ ദ്രാവിഡ ലിപിമാറ്റ നിയമം (Standard Dravidian phonetic baseline)');
    }

    // Normalize probabilities across top hypotheses
    const maxScore = wordHypotheses[0]?.score || 1;
    const hypothesesWithProb = wordHypotheses.map((h, idx) => ({
      arabi: h.arabi,
      score: h.score,
      probability: Math.max(10, Math.min(99, Math.round((h.score / (maxScore * 1.1)) * 100))) + '%',
      breakdown: h.steps.map(s => `${s.syllable} → ${s.selected} (${s.score} pt)`),
      steps: h.steps
    }));

    const bestCandidate = wordHypotheses[0]?.arabi || transliterateMalayalamToken(norm);

    const trace = {
      input: word,
      normalized: norm,
      graphemes: Array.from(norm),
      detectedPhonemes: syllables.map(s => ({
        raw: s.raw,
        onset: s.onset,
        nucleus: s.nucleus,
        coda: s.coda,
        position: s.isInitial ? 'ആദ്യം (Initial)' : s.isFinal ? 'അവസാനം (Final)' : 'മധ്യത്തിൽ (Medial)'
      })),
      candidateMappings: syllables.map((s, idx) => ({
        grapheme: s.raw,
        candidates: syllableCandidateMatrix[idx].map(c => ({
          arabi: c.arabi,
          score: c.score,
          tags: c.tags,
          description: c.description
        }))
      })),
      appliedLinguisticRules: appliedRules,
      candidateScores: hypothesesWithProb,
      selectedArabi: bestCandidate,
      method: 'probabilistic_beam_search'
    };

    return {
      text: bestCandidate,
      candidates: wordHypotheses.map(h => h.arabi),
      trace
    };
  }

  /**
   * Baseline Token-by-Token Transliteration (Fallback reference)
   */
  function transliterateMalayalamToken(token) {
    const len = token.length;
    let result = '';
    let i = 0;

    while (i < len) {
      const char = token[i];

      if (NUMERALS[char]) {
        result += NUMERALS[char];
        i++;
        continue;
      }

      let ligatureMatched = false;
      for (const [lig, arabiLig] of Object.entries(SPECIAL_LIGATURES)) {
        if (token.startsWith(lig, i)) {
          result += arabiLig;
          i += lig.length;
          ligatureMatched = true;
          break;
        }
      }
      if (ligatureMatched) continue;

      if (CHILLU_MAP[char]) {
        result += CHILLU_MAP[char];
        i++;
        continue;
      }

      const twoChar = token.substring(i, i + 2);
      if (INDEPENDENT_VOWELS[twoChar]) {
        result += INDEPENDENT_VOWELS[twoChar];
        i += 2;
        continue;
      }
      if (INDEPENDENT_VOWELS[char]) {
        result += INDEPENDENT_VOWELS[char];
        i++;
        continue;
      }

      if (ML_CONSONANTS_SET.has(char)) {
        const c1 = char;

        if (i + 1 < len && token[i + 1] === '്') {
          if (i + 2 < len && ML_CONSONANTS_SET.has(token[i + 2])) {
            const c2 = token[i + 2];

            if (c1 === c2) {
              const baseStem = PURE_CONSONANT_STEMS[c1] || BASE_CONSONANTS[c1];
              let nextIdx = i + 3;
              let matra = '';
              if (nextIdx < len && MATRA_MAP[token[nextIdx]]) {
                matra = token[nextIdx];
                nextIdx++;
              }

              let hasFollowupAnusvara = false;
              let hasFollowupVisarga = false;
              if (nextIdx < len && token[nextIdx] === 'ം') {
                hasFollowupAnusvara = true;
                nextIdx++;
              } else if (nextIdx < len && token[nextIdx] === 'ഃ') {
                hasFollowupVisarga = true;
                nextIdx++;
              }

              if (matra === '') {
                result += baseStem + 'َّ';
              } else if (matra === '്') {
                result += baseStem + 'ّْ';
              } else if (matra === 'ാ') {
                result += baseStem + 'َّا';
              } else if (matra === 'ി') {
                result += baseStem + 'ِّ';
              } else if (matra === 'ീ') {
                result += baseStem + 'ِّي';
              } else if (matra === 'ു') {
                result += baseStem + 'ُّ';
              } else if (matra === 'ൂ') {
                result += baseStem + 'ُّو';
              } else if (matra === 'െ') {
                result += baseStem + 'ّ٘';
              } else if (matra === 'േ') {
                result += baseStem + 'ّ٘ي';
              } else if (matra === 'ൈ') {
                result += baseStem + 'َّيْ';
              } else if (matra === 'ൊ') {
                result += baseStem + 'ّٗ';
              } else if (matra === 'ോ') {
                result += baseStem + 'ّٗو';
              } else if (matra === 'ൗ') {
                result += baseStem + 'َّوْ';
              } else if (matra === 'ൃ') {
                result += baseStem + 'ّْرْ';
              } else if (matra === 'ം') {
                result += baseStem + 'َّمْ';
              } else if (matra === 'ഃ') {
                result += baseStem + 'َّهْ';
              } else {
                result += baseStem + 'ّ' + (MATRA_MAP[matra] || '');
              }

              if (hasFollowupAnusvara) {
                result += 'مْ';
              } else if (hasFollowupVisarga) {
                result += 'هْ';
              }

              i = nextIdx;
              continue;
            } else {
              if (i + 3 < len && token[i + 3] === '്' && i + 4 < len && token[i + 4] === c2) {
                result += (PURE_CONSONANT_STEMS[c1] || BASE_CONSONANTS[c1]) + 'ْ';
                i += 2;
                continue;
              }

              const stem1 = PURE_CONSONANT_STEMS[c1] || BASE_CONSONANTS[c1];
              const stem2 = PURE_CONSONANT_STEMS[c2] || BASE_CONSONANTS[c2];

              result += stem1 + 'ْ';

              let nextIdx = i + 3;
              let matra = '';
              if (nextIdx < len && MATRA_MAP[token[nextIdx]]) {
                matra = token[nextIdx];
                nextIdx++;
              }

              let hasFollowupAnusvara = false;
              let hasFollowupVisarga = false;
              if (nextIdx < len && token[nextIdx] === 'ം') {
                hasFollowupAnusvara = true;
                nextIdx++;
              } else if (nextIdx < len && token[nextIdx] === 'ഃ') {
                hasFollowupVisarga = true;
                nextIdx++;
              }

              if (matra === '') {
                if (ASPIRATE_CONSONANTS[c2]) {
                  result += ASPIRATE_CONSONANTS[c2];
                } else {
                  result += stem2 + 'َ';
                }
              } else {
                if (ASPIRATE_CONSONANTS[c2]) {
                  result += ASPIRATE_CONSONANTS[c2] + MATRA_MAP[matra];
                } else {
                  result += stem2 + MATRA_MAP[matra];
                }
              }

              if (hasFollowupAnusvara) {
                result += 'مْ';
              } else if (hasFollowupVisarga) {
                result += 'هْ';
              }

              i = nextIdx;
              continue;
            }
          } else {
            const stem1 = PURE_CONSONANT_STEMS[c1] || BASE_CONSONANTS[c1];
            result += stem1 + 'ْ';
            i += 2;
            continue;
          }
        }

        let nextIdx = i + 1;
        let matra = '';
        if (nextIdx < len && MATRA_MAP[token[nextIdx]]) {
          matra = token[nextIdx];
          nextIdx++;
        }

        let hasFollowupAnusvara = false;
        let hasFollowupVisarga = false;
        if (nextIdx < len && token[nextIdx] === 'ം') {
          hasFollowupAnusvara = true;
          nextIdx++;
        } else if (nextIdx < len && token[nextIdx] === 'ഃ') {
          hasFollowupVisarga = true;
          nextIdx++;
        }

        if (matra === '') {
          if (ASPIRATE_CONSONANTS[char]) {
            result += ASPIRATE_CONSONANTS[char];
          } else {
            result += (PURE_CONSONANT_STEMS[char] || BASE_CONSONANTS[char]) + 'َ';
          }
        } else {
          if (ASPIRATE_CONSONANTS[char]) {
            result += ASPIRATE_CONSONANTS[char] + MATRA_MAP[matra];
          } else {
            result += (PURE_CONSONANT_STEMS[char] || BASE_CONSONANTS[char]) + MATRA_MAP[matra];
          }
        }

        if (hasFollowupAnusvara) {
          result += 'مْ';
        } else if (hasFollowupVisarga) {
          result += 'هْ';
        }

        i = nextIdx;
        continue;
      }

      if (MATRA_MAP[char]) {
        result += MATRA_MAP[char];
        i++;
        continue;
      }

      result += char;
      i++;
    }

    return result;
  }

  // =========================================================================
  // 5. PUBLIC TRANSLITERATION ENGINE API
  // =========================================================================

  /**
   * Main Forward Transliteration (Malayalam -> Arabi-Malayalam)
   * Powered by the Local Linguistic AI Engine
   * @param {string} text - Malayalam text input
   * @returns {string} - Arabi-Malayalam output
   */
  function malayalamToArabi(text) {
    if (!text) return '';
    const norm = normalizeMalayalam(text);

    // Split text into word and non-word tokens preserving punctuation
    const tokens = norm.split(/([^\p{L}\p{M}\p{N}\u200C\u200D]+)/u);
    let out = '';

    for (const token of tokens) {
      if (!token) continue;

      if (!/[\p{L}\p{M}]/u.test(token)) {
        out += token;
        continue;
      }

      const res = transliterateWordWithAI(token);
      out += res.text;
    }

    return out;
  }

  /**
   * Research & Debug Inspector API
   * Generates comprehensive linguistic analysis trace for any input text
   * @param {string} text - Malayalam text
   * @returns {object} - Full linguistic trace object
   */
  function inspect(text) {
    if (!text) return null;
    const norm = normalizeMalayalam(text);
    const tokens = norm.split(/([^\p{L}\p{M}\p{N}\u200C\u200D]+)/u);
    const wordTraces = [];

    for (const token of tokens) {
      if (!token || !/[\p{L}\p{M}]/u.test(token)) continue;
      const res = transliterateWordWithAI(token);
      if (res.trace) {
        wordTraces.push(res.trace);
      }
    }

    return {
      input: text,
      normalized: norm,
      totalWords: wordTraces.length,
      traces: wordTraces,
      finalOutput: malayalamToArabi(text)
    };
  }

  /**
   * Advanced Transliterate with live ambiguity detection and validation
   */
  function transliterate(text, options = {}) {
    const direction = options.direction || 'ML_TO_ARABI';
    let outputText = '';
    const ambiguities = [];
    let traceData = null;

    if (direction === 'ML_TO_ARABI') {
      outputText = malayalamToArabi(text);
      traceData = inspect(text);

      const words = text.trim().split(/\s+/);
      for (const word of words) {
        const cleanWord = word.replace(/[^\p{L}\p{M}]/gu, '');
        if (AMBIGUOUS_WORDS[cleanWord]) {
          ambiguities.push({
            inputWord: cleanWord,
            candidates: AMBIGUOUS_WORDS[cleanWord].candidates,
            reason: AMBIGUOUS_WORDS[cleanWord].reason
          });
        }
      }
    } else {
      outputText = arabiToMalayalam(text);
    }

    const validation = validateArabiMalayalam(direction === 'ML_TO_ARABI' ? outputText : text);

    return {
      text: outputText,
      status: validation.status,
      hasAmbiguity: ambiguities.length > 0,
      ambiguities,
      validation,
      trace: traceData
    };
  }

  /**
   * M&M T17 AI Engine Reverse Transliteration (Arabi-Malayalam -> Malayalam)
   */
  function arabiToMalayalam(text) {
    if (!text) return '';
    let s = text;

    s = s.replace(/ٰا?/g, 'َا');
    s = s.replace(/ۡ/g, 'ْ');
    s = s.replace(/([\u064E\u0650\u064F\u0658\u0657])\u0651/g, '\u0651$1');

    const tokens = s.split(/([^\p{L}\p{M}\p{N}]+)/u);
    let out = '';

    for (const token of tokens) {
      if (!token) continue;
      if (!/[\p{L}\p{M}]/u.test(token)) {
        out += token;
        continue;
      }

      if (REVERSE_LEXICAL_DICTIONARY[token]) {
        out += REVERSE_LEXICAL_DICTIONARY[token];
        continue;
      }

      let wordResult = '';
      let i = 0;
      const len = token.length;

      while (i < len) {
        const char = token[i];

        if (REVERSE_NUMERALS[char]) {
          wordResult += REVERSE_NUMERALS[char];
          i++;
          continue;
        }

        let ligMatched = false;
        for (const arLig of ARABI_LIGATURES_SORTED) {
          if (token.startsWith(arLig, i)) {
            wordResult += ARABI_LIGATURES_TO_ML[arLig];
            i += arLig.length;
            ligMatched = true;
            break;
          }
        }
        if (ligMatched) continue;

        if (token.startsWith('مْ', i)) {
          const next = i + 2 < len ? token[i + 2] : '';
          const isWordEnd = !next || /[\s\p{P}]/u.test(next);
          if (isWordEnd) {
            wordResult += 'ം';
            i += 2;
            continue;
          }
        }

        const two = token.substring(i, i + 2);
        if (ARABI_CHILLUS_TO_ML[two]) {
          const next = i + 2 < len ? token[i + 2] : '';
          const isWordEnd = !next || /[\s\p{P}]/u.test(next);
          if (two === 'رْ' || isWordEnd) {
            wordResult += ARABI_CHILLUS_TO_ML[two];
            i += 2;
            continue;
          }
        }

        let vowelMatched = false;
        for (const arVowel of ARABI_INDEP_VOWELS_SORTED) {
          if (token.startsWith(arVowel, i)) {
            wordResult += ARABI_INDEPENDENT_VOWELS[arVowel];
            i += arVowel.length;
            vowelMatched = true;
            break;
          }
        }
        if (vowelMatched) continue;

        let consonantMatched = false;
        for (const arCons of ARABI_CONSONANTS_SORTED) {
          if (token.startsWith(arCons, i)) {
            const mlBase = ARABI_BASE_CONSONANTS[arCons];
            let nextIdx = i + arCons.length;

            let isGeminated = false;
            if (nextIdx < len && token[nextIdx] === 'ّ') {
              isGeminated = true;
              nextIdx++;
            }

            let matchedMatra = '';
            for (const arMatra of ARABI_MATRAS_SORTED) {
              if (isGeminated && arMatra.startsWith('ّ')) continue;
              if (token.startsWith(arMatra, nextIdx)) {
                matchedMatra = ARABI_MATRAS_TO_ML[arMatra];
                nextIdx += arMatra.length;
                break;
              }
            }

            if (isGeminated) {
              let gem = (arCons === 'ڔ' || arCons === 'ر') ? 'റ്റ' : (mlBase + '്' + mlBase);
              wordResult += gem + matchedMatra;
            } else {
              wordResult += mlBase + matchedMatra;
            }

            i = nextIdx;
            consonantMatched = true;
            break;
          }
        }
        if (consonantMatched) continue;

        if (char === 'َ' || char === 'ْ') {
          i++;
          continue;
        }

        wordResult += char;
        i++;
      }

      out += wordResult;
    }

    return out;
  }

  /**
   * Validation grammar for Arabi-Malayalam orthography
   */
  function validateArabiMalayalam(text) {
    if (!text || !text.trim()) {
      return { isValid: true, status: 'valid', errors: [], warnings: [] };
    }

    const errors = [];
    const warnings = [];

    const validArabiRegex = /^[\u0600-\u06FF\s\p{P}\p{N}]+$/u;
    if (!validArabiRegex.test(text)) {
      errors.push('അറബി-മലയാളം അല്ലാത്ത അക്ഷരങ്ങളോ ചിഹ്നങ്ങളോ കണ്ടെത്തി');
    }

    if (/[\u064E\u0650\u064F\u0658\u0657]{2,}/u.test(text)) {
      errors.push('തുടർച്ചയായി ഒന്നിലധികം ഹർക്കത്തുകൾ (Diacritics) നൽകിയിരിക്കുന്നു');
    }

    if (/^\s*[\u064E\u0650\u064F\u0651\u0652\u0658\u0657]/u.test(text)) {
      errors.push('അക്ഷരമില്ലാതെ ഹർക്കത്ത് മാത്രം ആരംഭത്തിൽ വന്നിരിക്കുന്നു');
    }

    const hasAmbiguity = Object.keys(AMBIGUOUS_WORDS).some(w => text.includes(w));
    if (hasAmbiguity) {
      warnings.push('ഈ വാചകത്തിൽ ഒന്നിലധികം എഴുത്തുരീതികളുള്ള (Ambiguous) പദങ്ങൾ ഉൾപ്പെട്ടിരിക്കുന്നു');
    }

    const status = errors.length > 0 ? 'invalid' : (warnings.length > 0 ? 'ambiguous' : 'valid');
    return {
      isValid: errors.length === 0,
      status,
      errors,
      warnings
    };
  }

  /**
   * Syllable & Linguistic Analyzer for students
   */
  function analyzeText(text) {
    if (!text) return [];
    const tokens = [];
    const words = text.trim().split(/(\s+)/);

    for (const token of words) {
      if (!token.trim()) {
        tokens.push({ malayalam: token, arabi: token, type: 'whitespace', rule: 'ഇടവേള (Space)' });
        continue;
      }

      if (LEXICAL_DICTIONARY[token]) {
        tokens.push({
          malayalam: token,
          arabi: LEXICAL_DICTIONARY[token],
          type: 'lexical',
          rule: `അറബി മൂല പദം (Lexical Loanword: ${token} → ${LEXICAL_DICTIONARY[token]})`
        });
        continue;
      }

      const syllables = segmentMalayalamWord(token);
      for (const syl of syllables) {
        const ar = malayalamToArabi(syl.raw);
        let ruleDesc = '';

        if (syl.type === 'geminate') {
          ruleDesc = `ദ്വിത്വം / ശദ്ദ് (ّ) നിയമം: ഇരട്ടിപ്പ് (${syl.raw} → ${ar})`;
        } else if (syl.type === 'chillu') {
          ruleDesc = `ചില്ലക്ഷരം: സുകൂൻ സഹിതം (${syl.raw} → ${ar})`;
        } else if (syl.type === 'independent_vowel') {
          ruleDesc = `സ്വതന്ത്ര സ്വരം (${syl.raw} → ${ar})`;
        } else if (syl.type === 'ligature') {
          ruleDesc = `പ്രത്യേക കൂട്ടക്ഷരം (${syl.raw} → ${ar})`;
        } else if (ASPIRATE_CONSONANTS[syl.onset]) {
          ruleDesc = `മഹാപ്രാണം (Do-Chashmi Heh ھ): ${syl.onset} → ${ar}`;
        } else {
          ruleDesc = `വ്യഞ്ജനവും സ്വരവും (${syl.raw} → ${ar})`;
        }

        tokens.push({
          malayalam: syl.raw,
          arabi: ar,
          type: syl.type,
          rule: ruleDesc
        });
      }
    }

    return tokens;
  }

  // =========================================================================
  // 6. EXTENSIBILITY API (Adding Rules & Patterns Without Engine Rewrite)
  // =========================================================================

  function registerCandidate(phoneme, candidateConfig) {
    if (!LINGUISTIC_KNOWLEDGE_BASE.candidates[phoneme]) {
      LINGUISTIC_KNOWLEDGE_BASE.candidates[phoneme] = [];
    }
    LINGUISTIC_KNOWLEDGE_BASE.candidates[phoneme].push(candidateConfig);
  }

  function registerPattern(patternConfig) {
    LINGUISTIC_KNOWLEDGE_BASE.morphologicalPatterns.unshift(patternConfig);
  }

  function registerLexicalEntry(mlWord, arabiWord) {
    LEXICAL_DICTIONARY[mlWord] = arabiWord;
  }

  return {
    ENGINE_INFO,
    malayalamToArabi,
    arabiToMalayalam,
    transliterate,
    inspect,
    validateArabiMalayalam,
    analyzeText,
    registerCandidate,
    registerPattern,
    registerLexicalEntry,
    LINGUISTIC_KNOWLEDGE_BASE,
    LEXICAL_DICTIONARY,
    AMBIGUOUS_WORDS,
    BASE_CONSONANTS,
    ASPIRATE_CONSONANTS,
    INDEPENDENT_VOWELS,
    MATRA_MAP,
    CHILLU_MAP,
    SPECIAL_LIGATURES
  };
}));
