#!/usr/bin/env python3
"""Local development server. Not intended for direct exposure to the internet."""
import os, json, sqlite3, secrets, hmac, time
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from http.cookies import SimpleCookie
from urllib.parse import urlparse, unquote
from pathlib import Path

ROOT = Path(__file__).resolve().parent
DATA = ROOT / 'data'
DATA.mkdir(exist_ok=True)
DB = DATA / 'site.sqlite3'
PASSWORD = os.environ.get('ADMIN_PASSWORD', '')
SESSIONS = {}

def connect():
    db = sqlite3.connect(DB, timeout=10)
    db.execute('CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY, title TEXT NOT NULL, body TEXT NOT NULL, created TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
    return db

class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs): super().__init__(*args, directory=str(ROOT), **kwargs)
    def send_json(self, status, data, headers=None):
        payload = json.dumps(data).encode('utf-8'); self.send_response(status)
        self.send_header('Content-Type','application/json; charset=utf-8'); self.send_header('Cache-Control','no-store')
        for k,v in (headers or {}).items(): self.send_header(k,v)
        self.send_header('Content-Length',str(len(payload))); self.end_headers(); self.wfile.write(payload)
    def session(self):
        cookie=SimpleCookie()
        try: cookie.load(self.headers.get('Cookie','')); token=cookie['session'].value
        except (KeyError, ValueError): return None
        session=SESSIONS.get(token)
        if not session or session['expires'] < time.time(): SESSIONS.pop(token,None); return None
        return session
    def read_json(self):
        try:
            length=int(self.headers.get('Content-Length','0'))
            if length < 1 or length > 8192: raise ValueError()
            value=json.loads(self.rfile.read(length)); return value if isinstance(value,dict) else None
        except (ValueError, json.JSONDecodeError, UnicodeDecodeError): return None
    def do_GET(self):
        path=urlparse(self.path).path
        if path == '/api/announcements':
            with connect() as db: rows=db.execute('SELECT id,title,body,created FROM announcements ORDER BY id DESC LIMIT 100').fetchall()
            return self.send_json(200,[dict(zip(('id','title','body','created'),r)) for r in rows])
        if path == '/api/session':
            session=self.session(); return self.send_json(200,{'authenticated':bool(session),'csrf':session['csrf'] if session else None})
        # Serve only explicit public assets; never expose the database or source code.
        decoded=unquote(path)
        if decoded == '/':
            self.path = '/index.html'
            decoded = '/index.html'
        candidate=Path(self.translate_path(decoded)).resolve()
        try: relative=candidate.relative_to(ROOT)
        except ValueError: return self.send_error(404)
        allowed=(relative.as_posix() in ('index.html','admin-panel.html') or
                 (relative.parts and relative.parts[0] in ('assets','pages','transliterator')))
        if not allowed or not candidate.is_file() or any(part.startswith('.') for part in relative.parts):
            return self.send_error(404)
        return super().do_GET()
    def do_POST(self):
        path=urlparse(self.path).path; data=self.read_json()
        if data is None: return self.send_json(400,{'error':'Invalid request.'})
        if path == '/api/login':
            if not PASSWORD: return self.send_json(503,{'error':'Set ADMIN_PASSWORD before starting the server.'})
            password=data.get('password','')
            if not isinstance(password,str) or not hmac.compare_digest(password.encode(),PASSWORD.encode()): return self.send_json(401,{'error':'Incorrect password.'})
            token=secrets.token_urlsafe(32); csrf=secrets.token_urlsafe(32); SESSIONS[token]={'csrf':csrf,'expires':time.time()+3600*8}
            return self.send_json(200,{'csrf':csrf},{'Set-Cookie':f'session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800'})
        session=self.session()
        if not session or not hmac.compare_digest(self.headers.get('X-CSRF-Token',''),session['csrf']): return self.send_json(403,{'error':'Please sign in again.'})
        if path == '/api/announcements':
            title=data.get('title'); body=data.get('body')
            if not isinstance(title,str) or not isinstance(body,str) or not 1 <= len(title.strip()) <= 120 or not 1 <= len(body.strip()) <= 2000: return self.send_json(400,{'error':'Enter a title (max 120 characters) and message (max 2000 characters).'})
            with connect() as db: db.execute('INSERT INTO announcements(title,body) VALUES (?,?)',(title.strip(),body.strip()))
            return self.send_json(201,{'ok':True})
        if path == '/api/delete':
            ident=data.get('id')
            if type(ident) is not int: return self.send_json(400,{'error':'Invalid ID.'})
            with connect() as db: db.execute('DELETE FROM announcements WHERE id=?',(ident,))
            return self.send_json(200,{'ok':True})
        if path == '/api/logout':
            cookie=SimpleCookie(); cookie.load(self.headers.get('Cookie','')); token=cookie['session'].value if 'session' in cookie else ''; SESSIONS.pop(token,None)
            return self.send_json(200,{'ok':True},{'Set-Cookie':'session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0'})
        return self.send_json(404,{'error':'Not found.'})

if __name__ == '__main__':
    connect().close(); port=int(os.environ.get('PORT','8000')); host=os.environ.get('HOST','127.0.0.1')
    print(f'Local development server: http://{host}:{port}',flush=True)
    if not PASSWORD: print('WARNING: set ADMIN_PASSWORD to enable the admin login.',flush=True)
    ThreadingHTTPServer((host,port),Handler).serve_forever()
