# Hidayathussibiyan Madrasa — rebuild

A fresh local-first website using the official logo and the original Luna Arabimalayalam transliterator. Public pages are rebuilt with shared styling. The original institutional recognition, learning direction and class-wise student-count placeholders have been restored. The independent Python/SQLite backend currently supports publishing and deleting announcements; these appear on both the homepage and announcements page.

## Run on your computer

Requires Python 3.9 or newer. In this folder:

**Windows PowerShell**
```powershell
$env:ADMIN_PASSWORD='choose-a-long-unique-password'
python server.py
```
**Mac or Linux**
```sh
export ADMIN_PASSWORD='choose-a-long-unique-password'
python3 server.py
```

Visit http://127.0.0.1:8000 and open Admin workspace to sign in. SQLite data lives in `data/site.sqlite3`; back it up privately. Never commit the password or database to a public repository.

## Current limitations

This is a local prototype, not production-ready. Only announcements have backend management. Exam results, teacher information and other official content are placeholders; results upload and management are not implemented. The new pages are English only; the original language selector has not yet been restored. Public pages include a light/dark theme control. The original transliteration engine and mapping are preserved; its HTML includes a new visual-only stylesheet. The server is for local development only: production needs HTTPS, stronger authentication and rate limiting, security review, backups, a suitable application server, and access controls. Do not use sensitive student data. A public result should be published only with the necessary permissions. The preview uses a shared demonstration password: do not use it for private content.
