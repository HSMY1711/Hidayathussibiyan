HIDAYATHUSSIBIYAN MADRASA — WEBSITE POLISH UPDATE

Included updates:
- Removed the hamburger menu and mobile menu markup from the homepage.
- Kept the hamburger menu on the standard content pages only.
- Reduced each content-page hamburger menu to a single Home link.
- Home always navigates to index.html (it is not a browser-back action).
- Added a persistent English / Kannada / Malayalam language selector to the public website pages.
- Added Kannada and Malayalam translations for the main public navigation, page headings, cards, notices, resource labels, and common interface copy.
- Kept the existing transliterator engine and mapping file unchanged.
- Preserved the existing branding, logos, theme behaviour, and page structure.
- Added responsive styling for the language selector.

Language selection is stored locally in the visitor's browser. The site is still a static front end; no production backend, published result PDFs, announcement feed, or admin authentication is created by this update.

QA performed:
- JavaScript syntax check passed for js/site.js.
- Local HTML asset/link checks passed for the homepage, public pages, and admin page.
- Verified that homepage has no hamburger menu.
- Verified that each standard content page has one hamburger menu and exactly one menu item: Home.
- ZIP integrity checked after packaging.

Note: Translations cover the main public-facing interface copy. Institution names, official names, personal names, and transliterator-generated content remain unchanged. Review Kannada and Malayalam wording with a fluent local speaker before public launch.
