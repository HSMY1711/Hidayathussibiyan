Hidayathussibiyan Madarasa — V34 Liquid Glass + Editorial Polish

This build evolves V33 with:
- A restrained Liquid Glass treatment for the site/admin headers, navigation, theme controls, and mobile menu. Main content cards remain opaque for readability.
- An editorial education-site layout inspired by university website patterns, without copying Loyola University Maryland branding or assets.
- A more polished teal/evergreen and violet mesh background, refined card spacing, button surfaces, focus states, and responsive typography.
- Updated custom SVG card logos matching the shown design direction: a violet educational-resource emblem with an open book, gold bookmark and star; a teal Usthad portrait with a clearly visible white kufi cap.
- More accessible mobile navigation state handling, including aria-hidden/expanded updates, Escape-to-close, outside-click closing, and keyboard focus cycling.
- No added remote font, video, or JavaScript dependencies. The original Arabimalayalam transliteration engine is unchanged.

Validation performed:
- Static local references and duplicate HTML IDs: passed across 9 HTML files.
- CSS parser: 0 parse errors.
- JavaScript syntax: passed for site.js and transliterator/arabi-malayalam.js.
- Custom SVG parsing: passed.
- ZIP integrity: checked after packaging.

A full interactive browser screenshot/regression pass could not be completed because Chromium navigation was blocked by the execution environment. Please run visual checks on desktop and mobile before deployment.
