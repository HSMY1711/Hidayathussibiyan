const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

// --- Navigation / accessible mobile menu --------------------------------------
const menuPairs = [];
function setMobileMenuState(button, panel, open, { returnFocus = false } = {}) {
  if (!button || !panel) return;
  panel.classList.toggle('open', open);
  button.setAttribute('aria-expanded', String(open));
  button.setAttribute('aria-label', open ? 'Close navigation' : 'Open navigation');
  panel.setAttribute('aria-hidden', String(!open));
  if (open) {
    requestAnimationFrame(() => panel.querySelector('a')?.focus({ preventScroll: true }));
  } else if (returnFocus) {
    button.focus({ preventScroll: true });
  }
}

document.querySelectorAll('.menu-toggle').forEach(button => {
  const header = button.closest('.site-header');
  const panel = header?.querySelector('.mobile-menu');
  if (!panel) return;
  if (panel.id) button.setAttribute('aria-controls', panel.id);
  panel.setAttribute('aria-hidden', 'true');
  button.setAttribute('aria-expanded', 'false');
  menuPairs.push({ button, panel, header });
  button.addEventListener('click', () => {
    setMobileMenuState(button, panel, button.getAttribute('aria-expanded') !== 'true');
  });
});

document.addEventListener('keydown', event => {
  const opened = menuPairs.find(pair => pair.panel.classList.contains('open'));
  if (!opened) return;
  if (event.key === 'Escape') {
    event.preventDefault();
    setMobileMenuState(opened.button, opened.panel, false, { returnFocus: true });
    return;
  }
  // Keep keyboard focus within the open navigation panel and its toggle.
  if (event.key === 'Tab') {
    const focusable = [opened.button, ...opened.panel.querySelectorAll('a[href]')];
    const first = focusable[0];
    const last = focusable[focusable.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault(); last?.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault(); first?.focus();
    }
  }
});

document.addEventListener('click', event => {
  menuPairs.forEach(({ button, panel, header }) => {
    if (panel.classList.contains('open') && header && !header.contains(event.target)) {
      setMobileMenuState(button, panel, false);
    }
  });
});

document.querySelectorAll('.mobile-menu a').forEach(link => {
  link.addEventListener('click', () => {
    const pair = menuPairs.find(item => item.panel === link.closest('.mobile-menu'));
    if (pair) setMobileMenuState(pair.button, pair.panel, false);
  });
});

const path = location.pathname;
document.querySelectorAll('.desktop-nav a,.mobile-menu a').forEach(a => {
  if (new URL(a.href, location.href).pathname === path) { a.classList.add('active'); a.setAttribute('aria-current', 'page'); }
});

// The internal-page menu's Home link always navigates to the actual homepage.
// --- Theme --------------------------------------------------------------------
// One shared theme state. Every theme button on the page is synchronised.
const themeButtons = [...document.querySelectorAll('.theme-toggle')];
const THEME_KEY = 'site-theme';
const getStoredTheme = () => { try { const value = localStorage.getItem(THEME_KEY); return value === 'dark' || value === 'light' ? value : null; } catch { return null; } };
const systemDark = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
const initialTheme = getStoredTheme() || (systemDark ? 'dark' : 'light');
document.documentElement.dataset.theme = initialTheme;

function syncThemeButtons() {
  const dark = document.documentElement.dataset.theme === 'dark';
  themeButtons.forEach(button => {
    button.setAttribute('aria-label', dark ? 'Switch to light theme' : 'Switch to dark theme');
    const label = button.querySelector('.theme-toggle__text');
    if (label) label.textContent = dark ? 'Switch to light theme' : 'Switch to dark theme';
    button.title = dark ? 'Switch to light theme' : 'Switch to dark theme';
  });
}
function setTheme(theme, persist = true) {
  document.documentElement.dataset.theme = theme === 'dark' ? 'dark' : 'light';
  if (persist) { try { localStorage.setItem(THEME_KEY, document.documentElement.dataset.theme); } catch { /* Theme still works for this page when storage is unavailable. */ } }
  syncThemeButtons();
}
themeButtons.forEach(button => button.addEventListener('click', () => {
  setTheme(document.documentElement.dataset.theme === 'dark' ? 'light' : 'dark');
}));
window.addEventListener('storage', event => {
  if (event.key === THEME_KEY && event.newValue) setTheme(event.newValue, false);
});
syncThemeButtons();


// Exam selectors give clear feedback while published result files are not configured.
const standardSelect = document.querySelector('[data-result-standard]');
const periodSelect = document.querySelector('[data-result-period]');
const resultStatus = document.querySelector('[data-result-status]');
function updateResultStatus() {
  if (!standardSelect || !periodSelect || !resultStatus) return;
  const language = document.documentElement.lang || 'en';
  if (language === 'kn') resultStatus.textContent = `${standardSelect.value} ತರಗತಿಯ ${periodSelect.value} ಫಲಿತಾಂಶ ಇನ್ನೂ ಪ್ರಕಟವಾಗಿಲ್ಲ.`;
  else if (language === 'ml') resultStatus.textContent = `${standardSelect.value} ക്ലാസിന്റെ ${periodSelect.value} ഫലം ഇതുവരെ പ്രസിദ്ധീകരിച്ചിട്ടില്ല.`;
  else resultStatus.textContent = `No ${periodSelect.value} result has been published for ${standardSelect.value} yet.`;
}
standardSelect?.addEventListener('change', updateResultStatus);
periodSelect?.addEventListener('change', updateResultStatus);
updateResultStatus();

// Scroll progress and pointer tracking removed: keep navigation responsive on low-end devices.

// Avoid entrance observers and delayed reveal effects; content is available immediately.

// --- Navigation performance --------------------------------------------------
// Use native browser navigation. Avoid View Transition interception here because
// it can introduce a noticeable delay on lower-powered/mobile devices.

const year = document.querySelector('[data-year]');
if (year) year.textContent = new Date().getFullYear();
// Student total: calculate automatically when official boys/girls values are supplied via data-count attributes.
const studentCounts = document.querySelectorAll('[data-student-count]');
if (studentCounts.length) {
  const boys = document.querySelector('[data-student-count="boys"]');
  const girls = document.querySelector('[data-student-count="girls"]');
  const total = document.querySelector('[data-student-count="total"]');
  const readCount = (node) => {
    const raw = node?.dataset.count;
    return raw !== undefined && raw.trim() !== '' && Number.isFinite(Number(raw)) && Number(raw) >= 0 ? Number(raw) : null;
  };
  const boyCount = readCount(boys);
  const girlCount = readCount(girls);
  if (boyCount !== null && girlCount !== null && total) {
    boys.textContent = boyCount.toLocaleString();
    girls.textContent = girlCount.toLocaleString();
    total.textContent = (boyCount + girlCount).toLocaleString();
  }
}


// V34 — restrained liquid-glass interaction: a soft highlight follows pointer
// position on large panels only. No layout measurement loops or external assets.
const liquidSurfaces = [...document.querySelectorAll('[data-liquid-surface]')];
const finePointer = window.matchMedia?.('(hover: hover) and (pointer: fine)').matches;
if (finePointer && !prefersReduced) {
  liquidSurfaces.forEach(surface => {
    let frame = 0;
    surface.addEventListener('pointermove', event => {
      if (frame) cancelAnimationFrame(frame);
      frame = requestAnimationFrame(() => {
        const rect = surface.getBoundingClientRect();
        const x = Math.max(0, Math.min(100, ((event.clientX - rect.left) / rect.width) * 100));
        const y = Math.max(0, Math.min(100, ((event.clientY - rect.top) / rect.height) * 100));
        surface.style.setProperty('--liquid-x', `${x}%`);
        surface.style.setProperty('--liquid-y', `${y}%`);
        frame = 0;
      });
    }, { passive: true });
    surface.addEventListener('pointerleave', () => {
      if (frame) cancelAnimationFrame(frame);
      frame = 0;
      surface.style.removeProperty('--liquid-x');
      surface.style.removeProperty('--liquid-y');
    }, { passive: true });
  });
}

// Match the browser chrome colour to the active theme where supported.
function syncThemeColor() {
  const meta = document.querySelector('meta[name="theme-color"]');
  if (meta) meta.setAttribute('content', document.documentElement.dataset.theme === 'dark' ? '#0b171a' : '#f7f4ed');
}
const originalSetTheme = setTheme;
setTheme = function(theme, persist = true) {
  originalSetTheme(theme, persist);
  syncThemeColor();
};
syncThemeColor();

// --- Website language: English, Kannada and Malayalam -----------------------
// Only interface copy is translated; names, published records and transliterator
// output are intentionally left untouched.
const websiteTranslations = {
  kn: {
    'Home':'ಮುಖಪುಟ','Madrasa':'ಮದ್ರಸ','Usthad':'ಉಸ್ತಾದ್','Resources':'ಸಂಪನ್ಮೂಲಗಳು','Results':'ಫಲಿತಾಂಶಗಳು','Announcements':'ಪ್ರಕಟಣೆಗಳು',
    'Faith · Knowledge · Education':'ನಂಬಿಕೆ · ಜ್ಞಾನ · ಶಿಕ್ಷಣ','A place to ':'','learn':'ಕಲಿಯಲು',', grow and serve.':', ಬೆಳೆಯಲು ಮತ್ತು ಸೇವೆ ಮಾಡಲು.','The essentials, clearly arranged.':'ಅಗತ್ಯ ಮಾಹಿತಿಗಳು ಸರಳವಾಗಿ ಮತ್ತು ಕ್ರಮಬದ್ಧವಾಗಿ.','Move directly to the information, people, resources and updates that matter.':'ಮುಖ್ಯ ಮಾಹಿತಿ, ವ್ಯಕ್ತಿಗಳು, പഠന ಸಂಪನ್ಮೂಲಗಳು ಮತ್ತು ಹೊಸ ಪ್ರಕಟಣೆಗಳನ್ನು ಸುಲಭವಾಗಿ ವೀಕ್ಷಿಸಿ.',
    'Madrasa Information':'ಮದ್ರಸ ಮಾಹಿತಿ','Institution details, learning direction and standards from 1st to 10th.':'ಸಂಸ್ಥೆಯ ವಿವರಗಳು, ಕಲಿಕೆಯ ಮಾರ್ಗದರ್ಶನ ಮತ್ತು 1ರಿಂದ 10ನೇ ತರಗತಿಯ ಮಾಹಿತಿ.','Usthad Information':'ಉಸ್ತಾದ್ ಮಾಹಿತಿ','Find the Usthads and their official contact information.':'ಉಸ್ತಾದರ ವಿವರಗಳು ಮತ್ತು ಅಧಿಕೃತ ಸಂಪರ್ಕ ಮಾಹಿತಿಯನ್ನು ತಿಳಿಯಿರಿ.','Learning Resources':'ಕಲಿಕಾ ಸಂಪನ್ಮೂಲಗಳು','Digital study resources, including the Arabimalayalam Transliterator.':'ಅರಬಿಮಲಯಾಳಂ ಲಿಪ್ಯಂತರ ಸಾಧನ ಸೇರಿದಂತೆ ಡಿಜಿಟಲ್ ಕಲಿಕಾ ಸಂಪನ್ಮೂಲಗಳು.','Exam Results':'ಪರೀಕ್ಷಾ ಫಲಿತಾಂಶಗಳು','Choose a standard and examination period to access published results.':'ಪ್ರಕಟಿತ ಫಲಿತಾಂಶಗಳನ್ನು ವೀಕ್ಷಿಸಲು ತರಗತಿ ಮತ್ತು ಪರೀಕ್ಷಾ ಅವಧಿಯನ್ನು ಆಯ್ಕೆಮಾಡಿ.','Official messages published for the Madarasa community.':'ಮದ್ರಸ ಸಮುದಾಯಕ್ಕಾಗಿ ಪ್ರಕಟಿಸಲಾದ ಅಧಿಕೃತ ಸಂದೇಶಗಳು.','Jashne Rabeeh':'ಜಶ್ನೆ ರಬೀಹ್','A special programme with its own dedicated digital experience.':'ವಿಶೇಷ ಕಾರ್ಯಕ್ರಮಕ್ಕಾಗಿ ಪ್ರತ್ಯೇಕ ಡಿಜಿಟಲ್ ವೇದಿಕೆ.','Separate platform':'ಪ್ರತ್ಯೇಕ ವೇದಿಕೆ','Faith':'ನಂಬಿಕೆ','Knowledge':'ಜ್ಞಾನ','Character':'ಸದ್ಗುಣ','Service':'ಸೇವೆ','Guidance in daily life':'ದೈನಂದಿನ ಜೀವನಕ್ಕೆ ಮಾರ್ಗದರ್ಶನ','Learning with purpose':'ಉದ್ದೇಶಪೂರ್ಣ ಕಲಿಕೆ','Values in action':'ಮೌಲ್ಯಗಳ ಆಚರಣೆ','Growing for community':'ಸಮುದಾಯಕ್ಕಾಗಿ ಬೆಳವಣಿಗೆ',
    'Latest':'ಇತ್ತೀಚಿನವು','No announcements have been published yet.':'ಇನ್ನೂ ಯಾವುದೇ ಪ್ರಕಟಣೆಗಳನ್ನು ಪ್ರಕಟಿಸಲಾಗಿಲ್ಲ.','When a notice is published, it will appear here.':'ಸೂಚನೆ ಪ್ರಕಟವಾದಾಗ ಅದು ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ.','Open announcements':'ಪ್ರಕಟಣೆಗಳನ್ನು ತೆರೆಯಿರಿ','Institution':'ಸಂಸ್ಥೆ','Institutional recognition':'ಸಂಸ್ಥೆಯ ಮಾನ್ಯತೆ','Recognition':'ಮಾನ್ಯತೆ','Learning direction':'ಕಲಿಕೆಯ ಮಾರ್ಗದರ್ಶನ','Faith and knowledge':'ನಂಬಿಕೆ ಮತ್ತು ಜ್ಞಾನ','Student community':'ವಿದ್ಯಾರ್ಥಿ ಸಮುದಾಯ','Student count':'ವಿದ್ಯಾರ್ಥಿಗಳ ಸಂಖ್ಯೆ','Current student figures can be published here when the official counts are available.':'ಅಧಿಕೃತ ಸಂಖ್ಯೆಗಳು ಲಭ್ಯವಾದಾಗ ಪ್ರಸ್ತುತ ವಿದ್ಯಾರ್ಥಿಗಳ ವಿವರಗಳನ್ನು ಇಲ್ಲಿ ಪ್ರಕಟಿಸಬಹುದು.','Boys':'ಗಂಡು ಮಕ್ಕಳು','Girls':'ಹೆಣ್ಣು ಮಕ್ಕಳು','Total students':'ಒಟ್ಟು ವಿದ್ಯಾರ್ಥಿಗಳು','Registered students':'ನೋಂದಾಯಿತ ವಿದ್ಯಾರ್ಥಿಗಳು','Boys + girls':'ಗಂಡು ಮಕ್ಕಳು + ಹೆಣ್ಣು ಮಕ್ಕಳು',
    'People':'ವ್ಯಕ್ತಿಗಳು','The Usthads and their official contact details.':'ಉಸ್ತಾದರು ಮತ್ತು ಅವರ ಅಧಿಕೃತ ಸಂಪರ್ಕ ವಿವರಗಳು.','Usthad name':'ಉಸ್ತಾದರ ಹೆಸರು','Official name':'ಅಧಿಕೃತ ಹೆಸರು','Official contact':'ಅಧಿಕೃತ ಸಂಪರ್ಕ','Academic record':'ಶೈಕ್ಷಣಿಕ ದಾಖಲೆ','Select a standard and examination period. Published PDFs will appear in the reserved viewing area.':'ತರಗತಿ ಮತ್ತು ಪರೀಕ್ಷಾ ಅವಧಿಯನ್ನು ಆಯ್ಕೆಮಾಡಿ. ಪ್ರಕಟಿತ PDF ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ.','Choose':'ಆಯ್ಕೆಮಾಡಿ','Examination result':'ಪರೀಕ್ಷಾ ಫಲಿತಾಂಶ','Mid-Term':'ಅರ್ಧವಾರ್ಷಿಕ','Final':'ವಾರ್ಷಿಕ','Final results':'ಅಂತಿಮ ಫಲಿತಾಂಶಗಳು','Reserved external result area':'ಬಾಹ್ಯ ಫಲಿತಾಂಶ ವಿಭಾಗ','No result has been published yet.':'ಇನ್ನೂ ಯಾವುದೇ ಫಲಿತಾಂಶ ಪ್ರಕಟವಾಗಿಲ್ಲ.','A published result PDF will appear here when available.':'ಫಲಿತಾಂಶದ PDF ಲಭ್ಯವಾದಾಗ ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತದೆ.','External result destination · not available':'ಬಾಹ್ಯ ಫಲಿತಾಂಶದ ಲಿಂಕ್ · ಲಭ್ಯವಿಲ್ಲ',
    'Official updates':'ಅಧಿಕೃತ ಪ್ರಕಟಣೆಗಳು','A simple public channel for official messages and notices.':'ಅಧಿಕೃತ ಸಂದೇಶಗಳು ಮತ್ತು ಸೂಚನೆಗಳಿಗಾಗಿ ಸಾರ್ವಜನಿಕ ವಿಭಾಗ.','No announcements yet.':'ಇನ್ನೂ ಪ್ರಕಟಣೆಗಳಿಲ್ಲ.','The public announcement feed is currently empty. Published notices will appear here.':'ಪ್ರಸ್ತುತ ಪ್ರಕಟಣೆಗಳ ವಿಭಾಗ ಖಾಲಿಯಾಗಿದೆ. ಪ್ರಕಟಿತ ಸೂಚನೆಗಳು ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತವೆ.',
    'Educational Resources':'ಶೈಕ್ಷಣಿಕ ಸಂಪನ್ಮೂಲಗಳು','Study materials and useful digital tools selected to support Madarasa learning.':'ಮದ್ರಸ ಕಲಿಕೆಗೆ ಸಹಾಯ ಮಾಡುವ ಅಧ್ಯಯನ ಸಾಮಗ್ರಿಗಳು ಮತ್ತು ಡಿಜಿಟಲ್ ಸಾಧನಗಳು.','Explore':'ಅನ್ವೇಷಿಸಿ','Available resources':'ಲಭ್ಯವಿರುವ ಸಂಪನ್ಮೂಲಗಳು','Choose a resource to study, watch lessons or use the transliterator.':'ಅಧ್ಯಯನ ಮಾಡಲು, ಪಾಠಗಳನ್ನು ವೀಕ್ಷಿಸಲು ಅಥವಾ ಲಿಪ್ಯಂತರ ಸಾಧನ ಬಳಸಲು ಸಂಪನ್ಮೂಲವನ್ನು ಆಯ್ಕೆಮಾಡಿ.','Madarasa Guide':'ಮದ್ರಸ ಗೈಡ್','Al IHSAN':'ಅಲ್ ಇಹ್ಸಾನ್','Arabimalayalam Transliterator':'ಅರಬಿಮಲಯಾಳಂ ಲಿಪ್ಯಂತರ ಸಾಧನ','Open tool ↗':'ಸಾಧನ ತೆರೆಯಿರಿ ↗','Open channel ↗':'ಚಾನೆಲ್ ತೆರೆಯಿರಿ ↗','Google Play':'ಗೂಗಲ್ ಪ್ಲೇ','App Store':'ಆಪ್ ಸ್ಟೋರ್','Skip to content':'ವಿಷಯಕ್ಕೆ ತೆರಳಿ'
  },
  ml: {
    'Home':'ഹോം','Madrasa':'മദ്റസ','Usthad':'ഉസ്താദ്','Resources':'വിഭവങ്ങൾ','Results':'ഫലങ്ങൾ','Announcements':'അറിയിപ്പുകൾ',
    'Faith · Knowledge · Education':'വിശ്വാസം · വിജ്ഞാനം · വിദ്യാഭ്യാസം','A place to ':'','learn':'പഠിക്കാനും',', grow and serve.':', വളരാനും സേവിക്കാനും.','The essentials, clearly arranged.':'പ്രധാന വിവരങ്ങൾ വ്യക്തമായ ക്രമത്തിൽ.','Move directly to the information, people, resources and updates that matter.':'പ്രധാന വിവരങ്ങൾ, വ്യക്തികൾ, പഠനവിഭവങ്ങൾ, പുതിയ അറിയിപ്പുകൾ എന്നിവ എളുപ്പത്തിൽ കാണുക.',
    'Madrasa Information':'മദ്റസ വിവരങ്ങൾ','Institution details, learning direction and standards from 1st to 10th.':'സ്ഥാപന വിവരങ്ങൾ, പഠനരീതി, ഒന്നാം ക്ലാസ് മുതൽ പത്താം ക്ലാസ് വരെയുള്ള വിവരങ്ങൾ.','Usthad Information':'ഉസ്താദ് വിവരങ്ങൾ','Find the Usthads and their official contact information.':'ഉസ്താദുമാരുടെയും അവരുടെ ഔദ്യോഗിക ബന്ധപ്പെടൽ വിവരങ്ങളും അറിയുക.','Learning Resources':'പഠനവിഭവങ്ങൾ','Digital study resources, including the Arabimalayalam Transliterator.':'അറബി മലയാളം ലിപ്യന്തരണ ഉപകരണം ഉൾപ്പെടെയുള്ള ഡിജിറ്റൽ പഠനവിഭവങ്ങൾ.','Exam Results':'പരീക്ഷാഫലങ്ങൾ','Choose a standard and examination period to access published results.':'പ്രസിദ്ധീകരിച്ച ഫലങ്ങൾ കാണാൻ ക്ലാസും പരീക്ഷാ കാലയളവും തിരഞ്ഞെടുക്കുക.','Official messages published for the Madarasa community.':'മദ്റസ സമൂഹത്തിനായി പ്രസിദ്ധീകരിക്കുന്ന ഔദ്യോഗിക സന്ദേശങ്ങൾ.','Jashne Rabeeh':'ജശ്നെ റബീഹ്','A special programme with its own dedicated digital experience.':'പ്രത്യേക ഡിജിറ്റൽ സംവിധാനമുള്ള പ്രത്യേക പരിപാടി.','Separate platform':'പ്രത്യേക പ്ലാറ്റ്ഫോം','Faith':'വിശ്വാസം','Knowledge':'വിജ്ഞാനം','Character':'സ്വഭാവഗുണം','Service':'സേവനം','Guidance in daily life':'ദൈനംദിന ജീവിതത്തിന് മാർഗനിർദേശം','Learning with purpose':'ലക്ഷ്യബോധത്തോടെയുള്ള പഠനം','Values in action':'മൂല്യങ്ങൾ ജീവിതത്തിൽ','Growing for community':'സമൂഹത്തിനായി വളരുക',
    'Latest':'പുതിയവ','No announcements have been published yet.':'ഇതുവരെ അറിയിപ്പുകളൊന്നും പ്രസിദ്ധീകരിച്ചിട്ടില്ല.','When a notice is published, it will appear here.':'ഒരു അറിയിപ്പ് പ്രസിദ്ധീകരിക്കുമ്പോൾ ഇവിടെ കാണിക്കും.','Open announcements':'അറിയിപ്പുകൾ തുറക്കുക','Institution':'സ്ഥാപനം','Institutional recognition':'സ്ഥാപനത്തിന്റെ അംഗീകാരം','Recognition':'അംഗീകാരം','Learning direction':'പഠനരീതി','Faith and knowledge':'വിശ്വാസവും വിജ്ഞാനവും','Student community':'വിദ്യാർത്ഥി സമൂഹം','Student count':'വിദ്യാർത്ഥികളുടെ എണ്ണം','Current student figures can be published here when the official counts are available.':'ഔദ്യോഗിക കണക്കുകൾ ലഭ്യമാകുമ്പോൾ നിലവിലെ വിദ്യാർത്ഥികളുടെ എണ്ണം ഇവിടെ പ്രസിദ്ധീകരിക്കാം.','Boys':'ആൺകുട്ടികൾ','Girls':'പെൺകുട്ടികൾ','Total students':'ആകെ വിദ്യാർത്ഥികൾ','Registered students':'രജിസ്റ്റർ ചെയ്ത വിദ്യാർത്ഥികൾ','Boys + girls':'ആൺകുട്ടികൾ + പെൺകുട്ടികൾ',
    'People':'വ്യക്തികൾ','The Usthads and their official contact details.':'ഉസ്താദുമാരുടെയും അവരുടെ ഔദ്യോഗിക ബന്ധപ്പെടൽ വിവരങ്ങളും.','Usthad name':'ഉസ്താദിന്റെ പേര്','Official name':'ഔദ്യോഗിക പേര്','Official contact':'ഔദ്യോഗിക ബന്ധപ്പെടൽ','Academic record':'വിദ്യാഭ്യാസ രേഖ','Select a standard and examination period. Published PDFs will appear in the reserved viewing area.':'ക്ലാസും പരീക്ഷാ കാലയളവും തിരഞ്ഞെടുക്കുക. പ്രസിദ്ധീകരിച്ച PDF ഇവിടെ കാണാം.','Choose':'തിരഞ്ഞെടുക്കുക','Examination result':'പരീക്ഷാഫലം','Mid-Term':'അർദ്ധവാർഷികം','Final':'വാർഷികം','Final results':'അന്തിമ ഫലങ്ങൾ','Reserved external result area':'ബാഹ്യ ഫലങ്ങൾക്കായുള്ള വിഭാഗം','No result has been published yet.':'ഇതുവരെ ഫലങ്ങളൊന്നും പ്രസിദ്ധീകരിച്ചിട്ടില്ല.','A published result PDF will appear here when available.':'ഫലത്തിന്റെ PDF ലഭ്യമാകുമ്പോൾ ഇവിടെ കാണിക്കും.','External result destination · not available':'ബാഹ്യ ഫല ലിങ്ക് · ലഭ്യമല്ല',
    'Official updates':'ഔദ്യോഗിക അറിയിപ്പുകൾ','A simple public channel for official messages and notices.':'ഔദ്യോഗിക സന്ദേശങ്ങൾക്കും അറിയിപ്പുകൾക്കുമുള്ള പൊതുവിഭാഗം.','No announcements yet.':'ഇതുവരെ അറിയിപ്പുകളില്ല.','The public announcement feed is currently empty. Published notices will appear here.':'നിലവിൽ അറിയിപ്പ് വിഭാഗം ശൂന്യമാണ്. പ്രസിദ്ധീകരിക്കുന്ന അറിയിപ്പുകൾ ഇവിടെ കാണിക്കും.',
    'Educational Resources':'വിദ്യാഭ്യാസ വിഭവങ്ങൾ','Study materials and useful digital tools selected to support Madarasa learning.':'മദ്റസ പഠനത്തെ സഹായിക്കുന്ന പഠനസാമഗ്രികളും പ്രയോജനകരമായ ഡിജിറ്റൽ ഉപകരണങ്ങളും.','Explore':'പര്യവേക്ഷണം','Available resources':'ലഭ്യമായ വിഭവങ്ങൾ','Choose a resource to study, watch lessons or use the transliterator.':'പഠിക്കാനും പാഠങ്ങൾ കാണാനും ലിപ്യന്തരണ ഉപകരണം ഉപയോഗിക്കാനും ഒരു വിഭവം തിരഞ്ഞെടുക്കുക.','Madarasa Guide':'മദ്റസ ഗൈഡ്','Al IHSAN':'അൽ ഇഹ്സാൻ','Arabimalayalam Transliterator':'അറബി മലയാളം ലിപ്യന്തരണ ഉപകരണം','Open tool ↗':'ഉപകരണം തുറക്കുക ↗','Open channel ↗':'ചാനൽ തുറക്കുക ↗','Google Play':'ഗൂഗിൾ പ്ലേ','App Store':'ആപ്പ് സ്റ്റോർ','Skip to content':'ഉള്ളടക്കത്തിലേക്ക് പോകുക'
  }
};

// Additional labels used in page headings, cards and footer areas.
Object.assign(websiteTranslations.kn, {
  'Institutional profile':'ಸಂಸ್ಥೆಯ ಪರಿಚಯ','Digital home':'ಡಿಜಿಟಲ್ ವೇದಿಕೆ','Yenmoor':'ಯೆന്മೂರು','The Madrasa':'ಮದ್ರಸ','Madarasa':'ಮದ್ರಸ','Madrasa':'ಮದ್ರಸ','Details participants':'ವಿದ್ಯಾರ್ಥಿಗಳ ವಿವರಗಳು',
  'Official updates':'ಅಧಿಕೃತ ಪ್ರಕಟಣೆಗಳು','Hidayathussibiyan Madrasa · Learning tools':'ಹಿದಾಯത്തുസ്സിബിയാൻ ಮದ್ರಸ · ಕಲಿಕಾ ಸಾಧನಗಳು','Study materials and digital tools.':'ಅಧ್ಯಯನ ಸಾಮಗ್ರಿಗಳು ಮತ್ತು ಡಿಜಿಟಲ್ ಸಾಧನಗಳು.','Class-wise student count':'ತರಗತಿವಾರು ವಿದ್ಯಾರ್ಥಿಗಳ ಸಂಖ್ಯೆ','Student records':'ವಿದ್ಯಾರ್ಥಿಗಳ ದಾಖಲೆಗಳು','Student totals by standard. Counts are shown when official class-wise figures are supplied.':'ತರಗತಿವಾರು ವಿದ್ಯಾರ್ಥಿಗಳ ಒಟ್ಟು ಸಂಖ್ಯೆ. ಅಧಿಕೃತ ಅಂಕಿಅಂಶಗಳನ್ನು ಒದಗಿಸಿದಾಗ ಇಲ್ಲಿ ತೋರಿಸಲಾಗುತ್ತದೆ.','All classes':'ಎಲ್ಲಾ ತರಗತಿಗಳು','Class':'ತರಗತಿ','Exam':'ಪರೀಕ್ಷೆ','Information':'ಮಾಹಿತಿ','Back':'ಹಿಂದೆ','Only published notices appear here.':'ಪ್ರಕಟಿತ ಸೂಚನೆಗಳು ಮಾತ್ರ ಇಲ್ಲಿ ಕಾಣಿಸುತ್ತವೆ.','A dash indicates that the official count has not been provided yet.':'ಅಧಿಕೃತ ಸಂಖ್ಯೆ ಇನ್ನೂ ನೀಡದಿದ್ದರೆ ಡ್ಯಾಶ್ ತೋರಿಸಲಾಗುತ್ತದೆ.','1st to 10th Standard':'1ರಿಂದ 10ನೇ ತರಗತಿ'
});
Object.assign(websiteTranslations.ml, {
  'Institutional profile':'സ്ഥാപനത്തിന്റെ പരിചയം','Digital home':'ഡിജിറ്റൽ വേദി','Yenmoor':'യെൻമൂർ','The Madrasa':'മദ്റസ','Madarasa':'മദ്റസ','Madrasa':'മദ്റസ','Details participants':'വിദ്യാർത്ഥികളുടെ വിവരങ്ങൾ',
  'Hidayathussibiyan Madrasa · Learning tools':'ഹിദായത്തുസ്സിബിയാൻ മദ്റസ · പഠനോപകരണങ്ങൾ','Study materials and digital tools.':'പഠനസാമഗ്രികളും ഡിജിറ്റൽ ഉപകരണങ്ങളും.','Class-wise student count':'ക്ലാസ് അടിസ്ഥാനത്തിലുള്ള വിദ്യാർത്ഥികളുടെ എണ്ണം','Student records':'വിദ്യാർത്ഥികളുടെ രേഖകൾ','Student totals by standard. Counts are shown when official class-wise figures are supplied.':'ക്ലാസ് അടിസ്ഥാനത്തിലുള്ള വിദ്യാർത്ഥികളുടെ ആകെ എണ്ണം. ഔദ്യോഗിക കണക്കുകൾ ലഭിക്കുമ്പോൾ ഇവിടെ കാണിക്കും.','All classes':'എല്ലാ ക്ലാസുകളും','Class':'ക്ലാസ്','Exam':'പരീക്ഷ','Information':'വിവരങ്ങൾ','Back':'തിരികെ','Only published notices appear here.':'പ്രസിദ്ധീകരിച്ച അറിയിപ്പുകൾ മാത്രമേ ഇവിടെ കാണിക്കൂ.','A dash indicates that the official count has not been provided yet.':'ഔദ്യോഗിക എണ്ണം ലഭ്യമല്ലെങ്കിൽ ഡാഷ് കാണിക്കും.','1st to 10th Standard':'ഒന്നാം ക്ലാസ് മുതൽ പത്താം ക്ലാസ് വരെ'
});
websiteTranslations.kn['A place to'] = 'ഒരു സ്ഥലം';
websiteTranslations.ml['A place to'] = 'ഒരു ഇടം';

const LANGUAGE_KEY = 'hidayathussibiyan-language';
function translateWebsite(language) {
  const dictionary = websiteTranslations[language] || {};
  const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      const parent = node.parentElement;
      if (!parent || parent.closest('script,style,textarea,input,[contenteditable="true"],.trans-host')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  });
  const nodes=[];
  while(walker.nextNode()) nodes.push(walker.currentNode);
  nodes.forEach(node => {
    if (!node.__originalText) node.__originalText = node.nodeValue;
    const original = node.__originalText;
    const key = original.trim();
    if (!key) return;
    if (language === 'en') node.nodeValue = original;
    else if (dictionary[key]) node.nodeValue = original.replace(key, dictionary[key]);
  });
  document.documentElement.lang = language === 'kn' ? 'kn' : language === 'ml' ? 'ml' : 'en';
  document.querySelectorAll('.site-language').forEach(select => select.value = language);
  if (typeof updateResultStatus === 'function') updateResultStatus();
}
const languageSelects = [...document.querySelectorAll('.site-language')];
let currentLanguage = 'en';
try { currentLanguage = localStorage.getItem(LANGUAGE_KEY) || 'en'; } catch {}
if (!['en','kn','ml'].includes(currentLanguage)) currentLanguage = 'en';
translateWebsite(currentLanguage);
languageSelects.forEach(select => select.addEventListener('change', () => {
  const language = ['en','kn','ml'].includes(select.value) ? select.value : 'en';
  try { localStorage.setItem(LANGUAGE_KEY, language); } catch {}
  translateWebsite(language);
}));

