HIDAYATHUSSIBIYAN MADRASA — FINAL POLISH RELEASE CANDIDATE

This package includes the main website, public pages, admin UI shell, and Arabimalayalam Transliterator.

Design updates:
- Selective liquid-glass navigation and card surfaces, with opaque/legible content surfaces retained.
- Unified sun/moon theme control on main site and admin, with local theme persistence where browser storage is available.
- Mobile navigation controls with keyboard/Escape handling and compact-screen visibility.
- Institution spelling standardized to “Madrasa” in public-facing institutional copy.
- User-provided JPG applied to Exam Results and user-provided SVG applied to Usthad cards.
- Custom resources icon (open book, bookmark, gold star).
- Transliteration engine preserved byte-for-byte from V34 source.

Important limitations:
- Student counts, Usthad names/phone numbers, result PDFs and announcements remain unfilled because official values/files were not supplied.
- Admin UI is a visual shell; it must be connected to and secured by the configured backend before managing live content.
- Browser-based interactive visual QA was not completed in this environment; static checks are listed in the delivery message.


CONTINUATION UPDATE — 2026-10-29
- Replaced the old sun/moon slider appearance with the exact user-supplied theme-button image (images/theme-button-user.jpg). The control still toggles the existing light/dark theme and remembers the selection in the browser.
- Updated the Learning Resources card and Resources page hero to use the supplied Educational Resources card logo (images/resources-logo-user.png) rather than the decorative substitute.
- Kept the existing Admin workspace and its local draft, import/export, resource editing, Usthad fields, result metadata, and announcement-draft interactions.
- IMPORTANT: Admin edits currently save to this browser only. This static ZIP does not contain secure login, shared database storage, file uploads, or public publishing. Those require backend credentials/configuration and server-side access controls; do not treat the local workspace as a production-secure CMS.


STABILITY PATCH — 2026-10-29 (mobile screenshot feedback)
- Theme control now has a fixed 48×48 circular footprint on desktop and mobile; no pill/slider, no shape/position animation, and no hover/press recolouring. The supplied icon remains inside a colourless Liquid Glass surface.
- Removed switch-style aria-pressed state; it remains a regular tap action that changes the page theme.
- Confirmed the supplied Educational Resources logo is used on both the homepage Learning Resources card and the Educational Resources page hero.
- Added a discreet homepage footer link to the Admin workspace so it can be reached without guessing the path.
- Admin remains a local-only static workspace: it has browser-local drafts and import/export controls, but no secure authentication, shared database, server uploads, or live publishing backend. Do not use it for real student data until those are implemented.

QUALITY-ASSURANCE COMPLETION — 2026-10-30

Completed in this release:
- Consistent Liquid Glass treatment for public and admin navigation, with readable/opaque dashboard content surfaces.
- Fixed the asymmetric 25px/9px hero corner override; hero panels now use consistent corner rounding. The exam result selector and empty-result card retain explicit matching rounded geometry and clipping.
- Fixed theme action semantics: theme controls are regular buttons, not aria-pressed toggle switches. The main site/admin theme action retains the fixed 48px circular glass control and supplied image. Transliterator theme persistence now tolerates unavailable browser storage.
- Added visible, announced admin field validation for empty homepage headline, malformed phone values, unsafe/invalid resource URLs, invalid external result URLs, invalid PDF selections, and empty announcement fields.
- Admin success messages now depend on successful localStorage writes. Import validation checks the expected record shapes and collection limits before replacing current drafts.
- Added keyboard focus visibility, readable form controls, dark-mode validation text, and horizontally scrollable table styling for future admin tables.
- Kept admin limitations explicit: no secure login, permission enforcement, remote database, server-side file upload, or public publishing backend is connected. Browser-local drafts are not production CMS functionality.

Static QA performed:
- 9 HTML documents inspected; all have page titles and expected main heading structure (the transliterator wrapper uses an iframe title).
- All local image, script, stylesheet and page-link references resolve; no broken in-page anchors found.
- All inline JavaScript blocks pass Node syntax checks; shared site.js passes Node syntax check.
- Stylesheet parses without CSS syntax errors.
- Transliterator regression checks pass for Malayalam→Arabimalayalam (മുസ്തഫ→مُصْطَفَى; ഫാത്തിമ→فَاطِمَة) and reverse (مُصْطَفَى→മുസ്തഫ).
- Supplied logo/image references remain in the project; theme and resources assets are referenced by their user-provided filenames.
- ZIP integrity is checked at packaging time.

Verification limitations:
- Headless browser execution is blocked by the runtime's browser policy, so real mouse/touch/keyboard interaction, visual screenshots at multiple breakpoints, theme contrast measurement, clipboard permission behaviour and browser storage persistence could not be certified here. Static checks are not a substitute for those interactive checks.
- Backend behaviour and Owner/Admin permissions cannot be verified or implemented without the actual backend project, credentials/configuration and server-side access policies. No backend connection is claimed.
